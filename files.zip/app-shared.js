'use strict';
/* =========================================================
   DỮ LIỆU MẶC ĐỊNH — COLREG 72
   (Nội dung diễn giải phục vụ giảng dạy, không phải văn bản luật gốc)
========================================================= */
const PART_LABELS = {
  A:  {title:"Phần A", sub:"Quy định chung"},
  B1: {title:"Phần B · Mục I", sub:"Hành động trong mọi tầm nhìn xa"},
  B2: {title:"Phần B · Mục II", sub:"Hành động khi nhìn thấy nhau"},
  B3: {title:"Phần B · Mục III", sub:"Hành động khi tầm nhìn xa hạn chế"},
  C:  {title:"Phần C", sub:"Đèn và dấu hiệu"},
  D:  {title:"Phần D", sub:"Tín hiệu âm thanh, ánh sáng"},
  E:  {title:"Phần E", sub:"Miễn trừ"}
};
const PART_ORDER = ["A","B1","B2","B3","C","D","E"];

const DEFAULT_RULES = [
{id:"r1",part:"A",num:"Điều 1",title:"Áp dụng",body:`Bộ quy tắc áp dụng cho mọi tàu thuyền hoạt động trên biển cả và các vùng nước liên thông mà tàu biển có thể qua lại được.`},
{id:"r2",part:"A",num:"Điều 2",title:"Trách nhiệm",body:`Không điều khoản nào của quy tắc miễn trừ trách nhiệm cho tàu, chủ tàu, thuyền trưởng hay thuyền viên nếu không thực hiện đầy đủ các biện pháp phòng ngừa theo thông lệ hàng hải thông thường, hoặc theo yêu cầu đặc biệt của hoàn cảnh cụ thể lúc đó.`},
{id:"r3",part:"A",num:"Điều 3",title:"Định nghĩa chung",body:`Giải thích các thuật ngữ dùng trong quy tắc: "tàu thuyền", "tàu máy", "tàu buồm", "tàu đang đánh cá", "thuỷ phi cơ", "tàu mất chủ động", "tàu bị hạn chế khả năng điều động", "tàu bị hạn chế do mớn nước", "đang chạy" (underway), chiều dài/chiều rộng tàu, và "tầm nhìn xa bị hạn chế".`},

{id:"r4",part:"B1",num:"Điều 4",title:"Áp dụng",body:`Các quy tắc trong Mục I áp dụng cho tàu thuyền trong mọi điều kiện tầm nhìn xa.`},
{id:"r5",part:"B1",num:"Điều 5",title:"Cảnh giới",body:`Mọi tàu thuyền phải luôn duy trì cảnh giới thích hợp bằng mắt và tai, cũng như bằng mọi phương tiện sẵn có phù hợp với hoàn cảnh, điều kiện hiện tại, để đánh giá đầy đủ tình huống và nguy cơ đâm va.`},
{id:"r6",part:"B1",num:"Điều 6",title:"Tốc độ an toàn",body:`Mọi tàu thuyền phải luôn chạy với tốc độ an toàn để có hành động tránh va hiệu quả và dừng lại trong khoảng cách phù hợp với hoàn cảnh. Cần xem xét: tầm nhìn xa, mật độ giao thông, khả năng quay trở của tàu, ánh sáng ban đêm, điều kiện gió nước dòng chảy, mớn nước so với độ sâu, và khả năng sử dụng radar.`},
{id:"r7",part:"B1",num:"Điều 7",title:"Nguy cơ đâm va",body:`Mọi tàu phải dùng mọi phương tiện sẵn có, phù hợp hoàn cảnh, để xác định sớm có tồn tại nguy cơ đâm va hay không; nếu còn nghi ngờ phải coi như nguy cơ đó tồn tại. Không được phán đoán chỉ dựa trên thông tin ít ỏi, đặc biệt là dữ liệu radar chưa đầy đủ. Cần đặc biệt chú ý xem phương vị la bàn của tàu đang đến gần có thay đổi đáng kể hay không — nếu gần như không đổi, nguy cơ đâm va có thể đang tồn tại.`},
{id:"r8",part:"B1",num:"Điều 8",title:"Hành động tránh va",body:`Hành động tránh va, nếu hoàn cảnh cho phép, phải rõ ràng, thực hiện sớm và phù hợp thực tiễn hàng hải tốt. Thay đổi hướng đi/tốc độ phải đủ lớn để tàu khác dễ nhận biết; tránh nhiều thay đổi nhỏ liên tiếp. Nếu đủ khoảng nước, chỉ thay đổi hướng đi có thể là biện pháp hiệu quả nhất nếu thực hiện sớm, dứt khoát. Hành động phải dẫn tới việc thông qua ở khoảng cách an toàn; nếu cần, phải giảm tốc, dừng máy hoặc cho máy chạy lùi.`},
{id:"r9",part:"B1",num:"Điều 9",title:"Luồng hẹp",body:`Tàu chạy dọc luồng hẹp phải giữ càng gần mép ngoài cùng bên phải của luồng càng tốt, nếu an toàn và thực tế. Tàu dài dưới 20m và tàu buồm không được cản trở tàu chỉ có thể hành trình an toàn trong phạm vi luồng; tàu đánh cá không được cản trở tàu khác đang chạy trong luồng. Cấm vượt nếu đòi hỏi tàu bị vượt phải hỗ trợ — tàu định vượt phải phát tín hiệu xin đường và được đồng ý. Khi tiếp cận khúc quanh hoặc đoạn bị che khuất, phải cảnh giác đặc biệt và phát tín hiệu phù hợp. Tránh neo trong luồng hẹp nếu có thể tránh được.`},
{id:"r10",part:"B1",num:"Điều 10",title:"Hệ thống phân luồng giao thông",body:`Tàu dùng hệ thống phân luồng phải chạy đúng hướng làn đường quy định, tránh xa đường/vùng phân cách, thường nhập và thoát ở đầu làn; khi buộc phải cắt ngang, nên cắt theo hướng vuông góc nhất có thể. Tàu đánh cá, tàu buồm, tàu dài dưới 20m không được cản trở tàu máy đang hành trình an toàn trong làn đường. Tránh neo đậu trong hệ thống phân luồng hoặc gần khu vực đầu/cuối luồng.`},

{id:"r11",part:"B2",num:"Điều 11",title:"Áp dụng",body:`Các quy tắc trong Mục II áp dụng cho tàu thuyền nhìn thấy nhau.`},
{id:"r12",part:"B2",num:"Điều 12",title:"Tàu buồm",body:`Khi hai tàu buồm có nguy cơ đâm va: nếu gió thổi vào các mạn khác nhau, tàu có gió thổi vào mạn trái phải nhường đường; nếu gió thổi cùng mạn, tàu ở phía trên gió nhường tàu ở phía dưới gió; nếu không xác định được tàu kia nhận gió mạn nào, phải nhường đường.`},
{id:"r13",part:"B2",num:"Điều 13",title:"Vượt",body:`Bất kể các quy định khác của Mục II, tàu vượt phải nhường đường cho tàu bị vượt. Một tàu được coi là đang vượt khi tiếp cận tàu khác từ hướng lệch quá 22,5° so với trục ngang về phía sau — ban đêm chỉ nhìn thấy đèn lái, không thấy đèn mạn nào của tàu kia. Khi còn nghi ngờ, phải coi mình là tàu vượt. Nghĩa vụ nhường đường vẫn còn cho đến khi đã vượt qua và cách xa hẳn, dù sau đó tình huống có chuyển thành cắt hướng.`},
{id:"r14",part:"B2",num:"Điều 14",title:"Tình huống đối đầu",body:`Khi hai tàu máy đi đối hướng hoặc gần đối hướng có nguy cơ đâm va, mỗi tàu phải chuyển hướng sang phải để đi qua mạn trái của nhau. Tình huống được coi là tồn tại khi một tàu thấy tàu kia ở phía trước hoặc gần phía trước, ban đêm thấy đèn cột thẳng hàng/gần thẳng hàng và/hoặc thấy cả hai đèn mạn. Nếu còn nghi ngờ, phải coi như tình huống đối đầu đang tồn tại.`},
{id:"r15",part:"B2",num:"Điều 15",title:"Tình huống cắt hướng",body:`Khi hai tàu máy cắt hướng nhau có nguy cơ đâm va, tàu nào nhìn thấy tàu kia ở mạn phải của mình phải nhường đường và, nếu hoàn cảnh cho phép, tránh cắt ngang phía trước tàu kia.`},
{id:"r16",part:"B2",num:"Điều 16",title:"Hành động của tàu nhường đường",body:`Mọi tàu có nghĩa vụ nhường đường phải có hành động sớm và dứt khoát để giữ khoảng cách an toàn với tàu kia.`},
{id:"r17",part:"B2",num:"Điều 17",title:"Hành động của tàu giữ hướng",body:`Khi một tàu có nghĩa vụ nhường đường, tàu kia (tàu giữ hướng) phải giữ nguyên hướng đi, tốc độ. Tàu giữ hướng có thể tự hành động tránh va ngay khi thấy rõ tàu nhường đường không hành động thích hợp; nếu tình huống trở nên quá gần đến mức không thể tránh va chỉ bằng hành động của tàu nhường đường, tàu giữ hướng phải có hành động tốt nhất giúp tránh va — kể cả không chuyển hướng sang trái đối với tàu đang ở mạn trái mình trong tình huống cắt hướng, nếu khả thi.`},
{id:"r18",part:"B2",num:"Điều 18",title:"Trách nhiệm giữa các loại tàu",body:`Trừ khi Điều 9, 10, 13 quy định khác: tàu máy đang chạy phải nhường đường cho tàu mất chủ động, tàu bị hạn chế khả năng điều động, tàu đang đánh cá, và tàu buồm (theo thứ tự ưu tiên giảm dần). Tàu buồm đang chạy phải nhường đường cho tàu mất chủ động, tàu bị hạn chế khả năng điều động, và tàu đang đánh cá. Mọi tàu (trừ tàu mất chủ động/hạn chế điều động) phải tránh cản trở tàu bị hạn chế do mớn nước; tàu này phải hành trình đặc biệt thận trọng. Thuỷ phi cơ nói chung phải tránh xa và không cản trở tàu thuyền khác.`},
{id:"r19",part:"B3",num:"Điều 19",title:"Hành động trong tầm nhìn xa hạn chế",body:`Áp dụng cho tàu không nhìn thấy nhau khi hành trình trong/gần khu vực tầm nhìn xa hạn chế. Mọi tàu máy phải chạy tốc độ an toàn phù hợp, sẵn sàng máy để điều động ngay. Khi phát hiện tàu khác qua radar, phải xác định có hình thành tình huống quá gần/nguy cơ đâm va hay không và hành động tránh va sớm nếu cần, tránh: chuyển hướng sang trái với tàu ở phía trước trục ngang (trừ khi đang vượt); chuyển hướng về phía tàu đang ở chính ngang hoặc sau chính ngang. Trừ khi đã xác định hết nguy cơ, tàu nghe tín hiệu sương mù ở phía trước trục ngang hoặc không tránh được tình huống quá gần phải giảm tốc tối thiểu, sẵn sàng dừng hẳn trớn tới, và hết sức thận trọng cho đến khi hết nguy cơ.`},

{id:"r20",part:"C",num:"Điều 20",title:"Áp dụng",body:`Quy định về đèn có hiệu lực từ hoàng hôn đến bình minh và trong tầm nhìn xa hạn chế; có thể trưng thêm ban ngày nếu cần. Dấu hiệu (hình khối) được trưng ban ngày theo quy định riêng cho từng loại tàu/hoạt động.`},
{id:"r21",part:"C",num:"Điều 21",title:"Định nghĩa (đèn)",body:`Đèn cột: đèn trắng chiếu cung 225° đặt trên trục dọc tàu. Đèn mạn: xanh lá (mạn phải) và đỏ (mạn trái), mỗi đèn chiếu cung 112,5°. Đèn lái: đèn trắng phía sau, chiếu cung 135°. Đèn kéo: đèn vàng phía sau. Đèn chớp: đèn chớp toàn vòng với tần suất quy định.`},
{id:"r22",part:"C",num:"Điều 22",title:"Tầm nhìn xa của đèn",body:`Quy định khoảng cách tối thiểu phải nhìn thấy được của từng loại đèn, phân theo chiều dài tàu (từ 50m trở lên, 12–50m, dưới 12m).`},
{id:"r23",part:"C",num:"Điều 23",title:"Tàu máy đang chạy",body:`Phải trưng: một đèn cột phía trước (tàu từ 50m trở lên trưng thêm đèn cột thứ hai phía sau, cao hơn), đèn mạn hai bên, và đèn lái.`},
{id:"r25",part:"C",num:"Điều 25",title:"Tàu buồm đang chạy, tàu chèo",body:`Trưng đèn mạn hai bên và đèn lái (không có đèn cột); có thể thêm hai đèn chớp toàn vòng đỏ trên xanh lá ở đỉnh cột.`},
{id:"r27",part:"C",num:"Điều 27",title:"Tàu mất chủ động, tàu hạn chế khả năng điều động",body:`Trưng hai đèn chớp toàn vòng đỏ–đỏ (hoặc hai hình cầu đen ban ngày) xếp thẳng đứng, kèm đèn/dấu hiệu bổ sung tuỳ loại hoạt động (nạo vét, rà phá thuỷ lôi, kéo phao...).`},
{id:"r30",part:"C",num:"Điều 30",title:"Tàu neo, tàu mắc cạn",body:`Tàu neo trưng đèn trắng toàn vòng ở mũi (và ở lái, thấp hơn, nếu tàu dài). Tàu mắc cạn trưng thêm hai đèn đỏ toàn vòng thẳng đứng.`},
{id:"r31",part:"C",num:"Điều 31",title:"Thuỷ phi cơ",body:`Khi không thể trưng đủ đèn/dấu hiệu như tàu máy, thuỷ phi cơ phải trưng đèn/tín hiệu gần giống nhất có thể với quy định.`},

{id:"r32",part:"D",num:"Điều 32",title:"Định nghĩa (còi)",body:`"Tiếng ngắn": âm thanh kéo dài khoảng 1 giây. "Tiếng dài": âm thanh kéo dài khoảng 4–6 giây.`},
{id:"r34",part:"D",num:"Điều 34",title:"Tín hiệu điều động và cảnh báo",body:`Khi nhìn thấy nhau: 1 tiếng ngắn = "tôi chuyển hướng sang phải"; 2 tiếng ngắn = "tôi chuyển hướng sang trái"; 3 tiếng ngắn = "máy của tôi đang chạy lùi". Trong luồng hẹp khi xin vượt: 2 dài + 1 ngắn (xin vượt mạn phải) hoặc 2 dài + 2 ngắn (xin vượt mạn trái); tàu bị vượt đồng ý bằng 1 dài–1 ngắn–1 dài–1 ngắn. Khi nghi ngờ hành động/ý định của tàu kia: phát ít nhất 5 tiếng ngắn liên tiếp (có thể kèm đèn chớp). Khi tiếp cận khúc quanh/đoạn luồng bị che khuất: phát 1 tiếng dài.`},
{id:"r35",part:"D",num:"Điều 35",title:"Tín hiệu âm thanh khi tầm nhìn xa hạn chế",body:`Tàu máy có trớn tới: 1 tiếng dài mỗi khoảng không quá 2 phút. Tàu máy đang chạy nhưng dừng trớn: 2 tiếng dài liên tiếp (cách nhau ~2 giây) mỗi khoảng không quá 2 phút. Tàu mất chủ động, hạn chế điều động, hạn chế do mớn nước, tàu buồm, tàu đánh cá, tàu đang kéo/đẩy: 1 dài + 2 ngắn mỗi khoảng không quá 2 phút. Tàu neo: hồi chuông nhanh ~5 giây mỗi khoảng không quá 1 phút (tàu ≥100m thêm chiêng ở lái). Tàu mắc cạn: tín hiệu chuông đặc biệt.`},

{id:"r38",part:"E",num:"Điều 38",title:"Miễn trừ",body:`Cho phép một số tàu đóng hoặc đã đặt sống chính trước ngày quy tắc có hiệu lực được miễn trừ tạm thời hoặc vĩnh viễn một số yêu cầu về vị trí, đặc tính kỹ thuật của đèn, dấu hiệu, tín hiệu âm thanh, trong thời gian chuyển tiếp quy định.`}
];

/* ===== Tình huống mô phỏng ===== */
const VESSEL_TYPES = {
  power:  {label:"Tàu máy"},
  sail:   {label:"Tàu buồm"},
  fishing:{label:"Tàu đánh cá"},
  restricted:{label:"Tàu hạn chế điều động"}
};

const DEFAULT_SCENARIOS = [
{
  id:"sc-headon",title:"Tình huống đối đầu (Head-on)",ruleRef:"Điều 14",roleTag:"both",
  summary:"Hai tàu máy đi ngược hướng nhau, cả hai đều phải chuyển hướng sang phải.",
  description:`Hai tàu máy đi ngược hướng hoặc gần như ngược hướng nhau, mỗi tàu nhìn thấy đèn cột / hình dáng tàu kia gần như thẳng phía trước mũi — có nguy cơ đâm va trực diện.`,
  action:`Cả hai tàu đều phải chủ động chuyển hướng sang bên phải (mạn phải) để đi qua mạn trái của nhau. Không tàu nào được coi là tàu giữ hướng trong tình huống này; hành động phải sớm và rõ ràng.`,
  soundSignals:[`Mỗi tàu phát 1 tiếng còi ngắn khi bắt đầu chuyển hướng sang phải.`],
  showTurnArrows:true,
  ownShip:{name:"Tàu ta",type:"power",x:210,y:322,heading:0,role:"both"},
  targetShip:{name:"Tàu mục tiêu",type:"power",x:210,y:108,heading:180,role:"both"},
  environment:{currentDir:45,currentSpeed:1.0,windDir:60,windSpeed:12,visibility:"Tốt",showCurrent:true,showWind:false}
},
{
  id:"sc-cross-giveway",title:"Cắt hướng — Tàu ta nhường đường",ruleRef:"Điều 15, 16",roleTag:"giveway",
  summary:"Tàu mục tiêu ở mạn phải của tàu ta — tàu ta phải nhường đường.",
  description:`Tàu ta và tàu mục tiêu đang cắt hướng nhau. Tàu mục tiêu ở phía mạn phải của tàu ta, hai hướng đi có khả năng giao nhau ở phía trước.`,
  action:`Tàu ta là tàu nhường đường: hành động sớm, dứt khoát — thường là giảm tốc độ và/hoặc chuyển hướng sang phải để đi qua phía sau lái tàu mục tiêu, tránh cắt ngang phía trước tàu đó.`,
  soundSignals:[`1 tiếng còi ngắn khi bắt đầu chuyển hướng sang phải (Điều 34).`],
  showTurnArrows:true,
  ownShip:{name:"Tàu ta",type:"power",x:145,y:290,heading:5,role:"giveway"},
  targetShip:{name:"Tàu mục tiêu",type:"power",x:320,y:230,heading:222,role:"standon"},
  environment:{currentDir:200,currentSpeed:0.5,windDir:180,windSpeed:8,visibility:"Tốt",showCurrent:true,showWind:false}
},
{
  id:"sc-cross-standon",title:"Cắt hướng — Tàu ta giữ hướng",ruleRef:"Điều 17",roleTag:"standon",
  summary:"Tàu mục tiêu ở mạn trái của tàu ta và phải nhường đường; tàu ta giữ hướng.",
  description:`Tàu mục tiêu đang tiếp cận từ phía mạn trái của tàu ta và có nghĩa vụ nhường đường theo Điều 15.`,
  action:`Tàu ta là tàu giữ hướng: giữ nguyên hướng đi, tốc độ. Chỉ tự hành động tránh va khi thấy rõ tàu mục tiêu không hành động thích hợp, hoặc khi hai tàu đã đến quá gần.`,
  soundSignals:[`Nếu buộc phải tự hành động: phát tín hiệu tương ứng (1 hoặc 2 tiếng ngắn).`,`Có thể phát 5 tiếng ngắn liên tiếp nếu nghi ngờ ý định của tàu kia.`],
  showTurnArrows:false,
  ownShip:{name:"Tàu ta",type:"power",x:272,y:288,heading:355,role:"standon"},
  targetShip:{name:"Tàu mục tiêu",type:"power",x:112,y:222,heading:130,role:"giveway"},
  environment:{currentDir:90,currentSpeed:1.2,windDir:100,windSpeed:10,visibility:"Tốt",showCurrent:true,showWind:false}
},
{
  id:"sc-overtaking",title:"Tàu ta vượt tàu khác",ruleRef:"Điều 13",roleTag:"giveway",
  summary:"Tàu ta tiếp cận từ phía sau trong cung 135° sau lái — tàu ta là tàu vượt.",
  description:`Tàu ta tiếp cận tàu mục tiêu từ phía sau, trong phạm vi cung 135° tính từ chính lái (quá 22,5° so với trục ngang về phía sau) — ban đêm chỉ nhìn thấy đèn lái của tàu mục tiêu.`,
  action:`Tàu ta là tàu vượt: phải nhường đường, giữ khoảng cách an toàn cho đến khi vượt hẳn và cách xa. Nghĩa vụ này vẫn còn ngay cả khi sau đó tình huống chuyển thành cắt hướng.`,
  soundSignals:[`Trong luồng hẹp, xin vượt mạn phải: 2 tiếng dài + 1 tiếng ngắn.`,`Trong luồng hẹp, xin vượt mạn trái: 2 tiếng dài + 2 tiếng ngắn.`,`Tàu bị vượt đồng ý: 1 dài – 1 ngắn – 1 dài – 1 ngắn.`],
  showTurnArrows:false,showOvertakingSector:"target",
  ownShip:{name:"Tàu ta",type:"power",x:210,y:312,heading:0,role:"giveway"},
  targetShip:{name:"Tàu mục tiêu",type:"power",x:210,y:170,heading:0,role:"standon"},
  environment:{currentDir:0,currentSpeed:0.8,windDir:340,windSpeed:6,visibility:"Tốt",showCurrent:true,showWind:false}
},
{
  id:"sc-beingovertaken",title:"Tàu ta bị tàu khác vượt",ruleRef:"Điều 13, 17",roleTag:"standon",
  summary:"Tàu mục tiêu tiếp cận từ phía sau tàu ta trong cung sau lái — tàu ta được vượt.",
  description:`Tàu mục tiêu tiếp cận tàu ta từ phía sau, trong cung 135° sau lái tàu ta — tàu mục tiêu là tàu vượt, tàu ta là tàu bị vượt.`,
  action:`Về nguyên tắc, tàu ta giữ nguyên hướng đi, tốc độ như một tàu giữ hướng; chỉ hành động nếu thấy rõ tàu vượt không hành động thích hợp hoặc tình huống trở nên quá gần.`,
  soundSignals:[`Theo dõi tín hiệu xin vượt của tàu mục tiêu (nếu trong luồng hẹp) và phản hồi phù hợp.`],
  showTurnArrows:false,showOvertakingSector:"own",
  ownShip:{name:"Tàu ta",type:"power",x:210,y:170,heading:0,role:"standon"},
  targetShip:{name:"Tàu mục tiêu",type:"power",x:210,y:312,heading:0,role:"giveway"},
  environment:{currentDir:0,currentSpeed:0.8,windDir:340,windSpeed:6,visibility:"Tốt",showCurrent:true,showWind:false}
},
{
  id:"sc-power-sail",title:"Tàu máy gặp tàu buồm",ruleRef:"Điều 18",roleTag:"giveway",
  summary:"Tàu ta (tàu máy) phải nhường đường cho tàu buồm.",
  description:`Tàu ta (tàu máy) và tàu mục tiêu (tàu buồm) có nguy cơ đâm va khi cả hai đang chạy — đây không phải trường hợp vượt.`,
  action:`Tàu ta (tàu máy) phải nhường đường cho tàu buồm: chuyển hướng hoặc giảm tốc độ sớm để giữ khoảng cách an toàn.`,
  soundSignals:[`1 tiếng ngắn nếu chuyển hướng sang phải.`,`2 tiếng ngắn nếu chuyển hướng sang trái.`],
  showTurnArrows:true,
  ownShip:{name:"Tàu ta",type:"power",x:150,y:288,heading:20,role:"giveway"},
  targetShip:{name:"Tàu mục tiêu",type:"sail",x:296,y:196,heading:250,role:"standon"},
  environment:{currentDir:270,currentSpeed:0.6,windDir:250,windSpeed:14,visibility:"Tốt",showCurrent:true,showWind:true}
},
{
  id:"sc-narrowchannel",title:"Hành trình trong luồng hẹp",ruleRef:"Điều 9",roleTag:"neutral",
  summary:"Hai tàu đi ngược chiều trong luồng hẹp — mỗi tàu giữ sát mép phải.",
  description:`Tàu ta hành trình dọc theo luồng hẹp, gặp tàu mục tiêu đi ngược chiều trong cùng luồng.`,
  action:`Cả hai tàu phải giữ càng gần mép ngoài cùng bên phải của luồng càng tốt (nếu an toàn, thực tế); không cản trở tàu chỉ có thể an toàn trong phạm vi luồng; đặc biệt thận trọng tại khúc quanh.`,
  soundSignals:[`1 tiếng dài khi tiếp cận khúc quanh hoặc đoạn luồng bị che khuất tầm nhìn.`],
  showTurnArrows:false,showChannel:true,
  ownShip:{name:"Tàu ta",type:"power",x:165,y:300,heading:345,role:"neutral"},
  targetShip:{name:"Tàu mục tiêu",type:"power",x:255,y:130,heading:165,role:"neutral"},
  environment:{currentDir:160,currentSpeed:1.5,windDir:170,windSpeed:9,visibility:"Trung bình",showCurrent:true,showWind:false}
},
{
  id:"sc-restrictedvis",title:"Tầm nhìn xa bị hạn chế",ruleRef:"Điều 19, 35",roleTag:"caution",
  summary:"Sương mù — mục tiêu chỉ được phát hiện qua radar, chưa nhìn thấy bằng mắt.",
  description:`Trời có sương mù, tầm nhìn xa bị hạn chế. Tàu ta phát hiện một mục tiêu qua radar nhưng chưa nhìn thấy bằng mắt thường.`,
  action:`Chạy tốc độ an toàn phù hợp tầm nhìn hạn chế, sẵn sàng máy. Dùng radar đánh giá nguy cơ đâm va sớm; nếu mục tiêu ở phía trước trục ngang, tránh chuyển hướng sang trái hoặc về phía tàu đang ở ngang/sau ngang. Nếu nghe tín hiệu sương mù phía trước trục ngang hoặc không tránh được tình huống quá gần, giảm tốc tối thiểu, sẵn sàng dừng hẳn trớn tới.`,
  soundSignals:[`Tàu ta (có trớn tới) phát 1 tiếng dài mỗi khoảng không quá 2 phút.`],
  showTurnArrows:false,showFog:true,
  ownShip:{name:"Tàu ta",type:"power",x:210,y:296,heading:0,role:"neutral"},
  targetShip:{name:"Mục tiêu radar",type:"power",x:300,y:150,heading:200,role:"caution",radarOnly:true},
  environment:{currentDir:30,currentSpeed:0.7,windDir:20,windSpeed:5,visibility:"Hạn chế (sương mù)",showCurrent:true,showWind:false}
}
];

/* ===== Câu hỏi ôn tập ===== */
const DEFAULT_QUIZ = [
{id:"q1",prompt:`Theo Điều 13, một tàu được coi là "tàu vượt" khi nào?`,options:[
  "Khi tiếp cận tàu khác từ phía trước mũi",
  "Khi tiếp cận tàu khác từ hướng lệch quá 22,5° so với trục ngang về phía sau (chỉ thấy đèn lái)",
  "Khi hai tàu đi ngược hướng nhau",
  "Khi tàu kia đang neo đậu"],correct:1,
  explain:`Theo Điều 13, tàu vượt là tàu tiếp cận từ phía sau trong phạm vi cung sao cho ban đêm chỉ nhìn thấy đèn lái, không thấy đèn mạn nào của tàu bị vượt.`},
{id:"q2",prompt:`Trong tình huống đối đầu (Điều 14), hai tàu máy phải hành động như thế nào?`,options:[
  "Cả hai đều chuyển hướng sang trái",
  "Một tàu giữ nguyên hướng, tàu kia nhường đường",
  "Cả hai đều chuyển hướng sang phải",
  "Tàu lớn hơn được quyền ưu tiên"],correct:2,
  explain:`Điều 14 quy định cả hai tàu máy đi đối hướng đều phải chuyển hướng sang phải để đi qua mạn trái của nhau; không tàu nào là tàu giữ hướng trong tình huống này.`},
{id:"q3",prompt:`Trong tình huống cắt hướng (Điều 15), tàu nào phải nhường đường?`,options:[
  "Tàu nhìn thấy tàu kia ở mạn trái của mình",
  "Tàu nhìn thấy tàu kia ở mạn phải của mình",
  "Tàu đang chạy chậm hơn",
  "Tàu có kích thước nhỏ hơn"],correct:1,
  explain:`Điều 15 quy định tàu nào nhìn thấy tàu kia ở mạn phải của mình phải nhường đường và tránh cắt ngang phía trước tàu đó.`},
{id:"q4",prompt:`Tàu giữ hướng (Điều 17) được phép/phải tự hành động tránh va khi nào?`,options:[
  "Ngay khi phát hiện có tàu khác trong tầm nhìn",
  "Khi thấy rõ tàu nhường đường không có hành động thích hợp, hoặc khi hai tàu đã quá gần",
  "Chỉ khi được tàu nhường đường xin phép qua tín hiệu còi",
  "Không bao giờ được phép tự hành động"],correct:1,
  explain:`Điều 17 quy định tàu giữ hướng phải giữ nguyên hướng và tốc độ, nhưng có thể/phải tự hành động khi thấy rõ tàu nhường đường không hành động phù hợp, hoặc khi tình huống trở nên quá gần.`},
{id:"q5",prompt:`Theo Điều 18, tàu buồm đang chạy phải nhường đường cho loại tàu nào sau đây?`,options:[
  "Tàu máy đang chạy bình thường",
  "Tàu đang đánh cá",
  "Tàu khách",
  "Tàu container"],correct:1,
  explain:`Điều 18 quy định tàu buồm phải nhường đường cho tàu mất chủ động, tàu bị hạn chế khả năng điều động và tàu đang đánh cá.`},
{id:"q6",prompt:`Tín hiệu còi "1 tiếng ngắn" theo Điều 34 có nghĩa là gì?`,options:[
  "Tôi đang chuyển hướng sang trái",
  "Tôi đang chuyển hướng sang phải",
  "Máy của tôi đang chạy lùi",
  "Tôi nghi ngờ hành động của tàu kia"],correct:1,
  explain:`Theo Điều 34: 1 tiếng ngắn = "tôi chuyển hướng sang phải"; 2 tiếng ngắn = sang trái; 3 tiếng ngắn = máy đang chạy lùi.`},
{id:"q7",prompt:`Tín hiệu nào dùng để thể hiện sự nghi ngờ về hành động hoặc ý định của tàu kia?`,options:[
  "1 tiếng dài",
  "2 tiếng dài",
  "Ít nhất 5 tiếng ngắn liên tiếp",
  "1 dài + 2 ngắn"],correct:2,
  explain:`Điều 34 quy định khi nghi ngờ, phải phát ít nhất 5 tiếng ngắn liên tiếp (có thể kèm đèn chớp) để cảnh báo tàu kia.`},
{id:"q8",prompt:`Trong tầm nhìn xa bị hạn chế, tàu máy có trớn tới phải phát tín hiệu âm thanh nào?`,options:[
  "1 tiếng dài mỗi khoảng không quá 2 phút",
  "2 tiếng dài liên tiếp mỗi khoảng không quá 2 phút",
  "1 dài + 2 ngắn mỗi khoảng không quá 2 phút",
  "Hồi chuông nhanh mỗi khoảng không quá 1 phút"],correct:0,
  explain:`Điều 35 quy định tàu máy có trớn tới phát 1 tiếng dài mỗi khoảng không quá 2 phút; tàu dừng trớn phát 2 tiếng dài liên tiếp.`},
{id:"q9",prompt:`Theo Điều 19, khi phát hiện mục tiêu qua radar ở phía trước trục ngang trong tầm nhìn xa hạn chế, nên TRÁNH hành động nào?`,options:[
  "Giảm tốc độ",
  "Chuyển hướng sang trái",
  "Chuyển hướng sang phải",
  "Sẵn sàng máy"],correct:1,
  explain:`Điều 19 khuyến cáo tránh chuyển hướng sang trái đối với tàu ở phía trước trục ngang (trừ khi đang vượt), và tránh chuyển hướng về phía tàu đang ở ngang hoặc sau ngang.`},
{id:"q10",prompt:`Trong luồng hẹp, tàu nên hành trình ở vị trí nào trong luồng?`,options:[
  "Giữa luồng",
  "Càng gần mép ngoài cùng bên trái càng tốt",
  "Càng gần mép ngoài cùng bên phải càng tốt, nếu an toàn và thực tế",
  "Không có quy định cụ thể"],correct:2,
  explain:`Điều 9 quy định tàu chạy dọc luồng hẹp phải giữ càng gần mép ngoài cùng bên phải càng tốt, nếu an toàn và thực tế.`},
{id:"q11",prompt:`Tàu dài dưới 20m hoặc tàu buồm trong luồng hẹp có nghĩa vụ gì?`,options:[
  "Được quyền ưu tiên tuyệt đối",
  "Không được cản trở hành trình của tàu chỉ có thể an toàn trong phạm vi luồng hẹp",
  "Phải đi giữa luồng",
  "Không cần tuân theo quy tắc luồng hẹp"],correct:1,
  explain:`Điều 9 quy định tàu dài dưới 20m và tàu buồm không được cản trở hành trình an toàn của tàu chỉ có thể hành trình an toàn trong phạm vi luồng hẹp.`},
{id:"q12",prompt:`Theo Điều 6, yếu tố nào KHÔNG phải là căn cứ để xác định tốc độ an toàn?`,options:[
  "Tầm nhìn xa hiện tại",
  "Mật độ giao thông",
  "Khả năng quay trở của tàu",
  "Màu sơn của tàu"],correct:3,
  explain:`Điều 6 liệt kê các yếu tố như tầm nhìn xa, mật độ giao thông, khả năng điều động, ánh sáng, điều kiện gió nước, mớn nước so với độ sâu, khả năng radar... màu sơn tàu không liên quan.`},
{id:"q13",prompt:`Khi hai tàu buồm gặp nhau và gió thổi vào các mạn khác nhau, tàu nào phải nhường đường?`,options:[
  "Tàu có gió thổi vào mạn phải",
  "Tàu có gió thổi vào mạn trái",
  "Tàu lớn hơn",
  "Tàu đang ở phía dưới gió"],correct:1,
  explain:`Điều 12 quy định khi gió thổi vào các mạn khác nhau, tàu có gió thổi vào mạn trái phải nhường đường cho tàu có gió thổi vào mạn phải.`},
{id:"q14",prompt:`Đèn mạn phải (xanh lá) và đèn mạn trái (đỏ) trên tàu máy có góc chiếu sáng bao nhiêu độ mỗi bên?`,options:[
  "90°","112,5°","135°","225°"],correct:1,
  explain:`Điều 21 quy định mỗi đèn mạn chiếu sáng một cung 112,5° tính từ hướng mũi tàu về phía mạn tương ứng.`},
{id:"q15",prompt:`Tàu neo đậu vào ban đêm phải trưng đèn gì?`,options:[
  "Đèn trắng toàn vòng ở mũi (và ở lái nếu tàu dài)",
  "Hai đèn đỏ toàn vòng thẳng đứng",
  "Đèn xanh lá toàn vòng",
  "Không cần trưng đèn nếu neo trong vùng nước cạn"],correct:0,
  explain:`Điều 30 quy định tàu neo phải trưng đèn trắng toàn vòng ở nơi dễ thấy nhất phía mũi, và một đèn tương tự ở phía lái, thấp hơn, nếu tàu dài (tàu mắc cạn trưng thêm 2 đèn đỏ toàn vòng thẳng đứng).`}
];

const DEFAULT_SETTINGS = {
  appTitle:"VÀ PHÁT TRIỂN CÔNG NGHỆ BIỂN",
  orgName:"Trung tâm Đào tạo Thuyền viên",
  heroEyebrow:"COLREG 72 · QUY TẮC QUỐC TẾ PHÒNG NGỪA ĐÂM VA TÀU THUYỀN TRÊN BIỂN",
  heroLead:"Trực quan hoá các tình huống tránh va theo Bảng quy tắc quốc tế phòng ngừa đâm va tàu thuyền trên biển năm 1972 (COLREG 72)",
  footerText:"© VĐT - Trung tâm Đào tạo Thuyền viên và Phát triển Công nghệ biển - Tài liệu lưu hành nội bộ",
  emblem:"anchor",
  logoImageUrl:"https://trungtamdttv.edu.vn/uploads/0/DinhThi/LOGO/logo%20Cty%20(Final)%20.PNG.png",
  resultsWebhookUrl:"https://script.google.com/macros/s/AKfycbx1q3fYpe_7qyLpZSbTMiQwCd1ecNSXDC3IjkM0f_X6nQiYgJjPs-vO3up2fQy_a7lZYw/exec",
  examDurationMinutes:10,
  quizSheetUrl:"https://docs.google.com/spreadsheets/d/1N327z-MzawM8jiIJ_aBwe3uXwml6N9AmyriitH-YOy8/edit?usp=sharing",
  quizSheetProxyUrl:"https://script.google.com/macros/s/AKfycbyQYowBTZorSXDCufiSvOSxZYb33_QDKJiTGzF6RGlDjub81NqIHL-wWiEtbADVBWIN5g/exec",
  quizRandomCount:20,
  bannerImages:[
    {url:"https://trungtamdttv.edu.vn/Uploads/0/Sliders/7/img-2---web-240725212245.png", caption:""},
    {url:"https://trungtamdttv.edu.vn/Uploads/0/Sliders/1/img_8944---web-240725211527.png", caption:""}
  ]
};

const AUTH_USER = "TTDT";
const AUTH_PASS = "demo";

/* =========================================================
   LUẬT THUỶ SẢN — Danh mục văn bản (Luật, Nghị định, Thông tư)
   liên quan trực tiếp đến hoạt động khai thác thuỷ sản.
   Tổng hợp tham khảo — nên đối chiếu văn bản gốc khi sử dụng chính thức.
========================================================= */
const FISHERIES_DOCS = [
  {
    group:"Luật", tag:"Luật gốc",
    title:"Luật Thuỷ sản",
    code:"Số 18/2017/QH14",
    date:"Quốc hội thông qua 21/11/2017 — hiệu lực từ 01/01/2019",
    agency:"Quốc hội",
    status:"Còn hiệu lực — đã qua nhiều lần sửa đổi, bổ sung",
    summary:"Văn bản luật gốc thay thế Luật Thuỷ sản 2003, quy định về hoạt động thuỷ sản; quyền và nghĩa vụ của tổ chức, cá nhân hoạt động thuỷ sản; quản lý nhà nước về thuỷ sản trên các vùng nội địa, đảo, quần đảo và vùng biển Việt Nam.",
    points:[
      "Điều kiện, hạn ngạch và trình tự cấp Giấy phép khai thác thuỷ sản",
      "Quy định về tàu cá: đăng ký, đăng kiểm, đánh dấu, thuyền viên tàu cá",
      "Bảo vệ và phát triển nguồn lợi thuỷ sản, khu bảo tồn biển",
      "Các hành vi bị nghiêm cấm trong hoạt động thuỷ sản (Điều 7)"
    ]
  },
  {
    group:"Luật", tag:"Luật sửa đổi",
    title:"Luật sửa đổi, bổ sung một số điều của 15 luật lĩnh vực nông nghiệp và môi trường (có Luật Thuỷ sản)",
    code:"Số 146/2025/QH15",
    date:"Quốc hội thông qua 11/12/2025 — hiệu lực từ 01/01/2026",
    agency:"Quốc hội",
    status:"Đang áp dụng",
    summary:"Sửa đổi, bổ sung nhiều điều của Luật Thuỷ sản 2017 (trước đó đã được sửa bởi Luật số 31/2024/QH15 và 43/2024/QH15) nhằm hoàn thiện hành lang pháp lý chống khai thác IUU và đồng bộ mô hình quản lý hành chính 2 cấp.",
    points:[
      "Điều 14 của Luật sửa đổi hàng loạt khoản liên quan trực tiếp đến Luật Thuỷ sản",
      "Phân cấp thẩm quyền cấp phép, quản lý hạn ngạch khai thác",
      "Cập nhật thuật ngữ hành chính sau sáp nhập đơn vị (huyện → xã)"
    ]
  },
  {
    group:"Nghị định", tag:"Hướng dẫn thi hành",
    title:"Quy định chi tiết một số điều và biện pháp thi hành Luật Thuỷ sản",
    code:"Nghị định 26/2019/NĐ-CP",
    date:"Ban hành 08/3/2019",
    agency:"Chính phủ",
    status:"Đã được sửa đổi bởi NĐ 37/2024/NĐ-CP và NĐ 309/2025/NĐ-CP",
    summary:"Nghị định khung hướng dẫn chi tiết Luật Thuỷ sản: điều kiện cấp giấy phép khai thác, đăng ký/đăng kiểm tàu cá, hạn ngạch khai thác, thiết bị giám sát hành trình (VMS) và truy xuất nguồn gốc thuỷ sản khai thác.",
    points:[
      "Điều kiện, hồ sơ, trình tự cấp Giấy phép khai thác thuỷ sản",
      "Yêu cầu lắp thiết bị giám sát hành trình (VMS) với tàu cá dài ≥15m",
      "Kiểm soát thuỷ sản khai thác nhập khẩu qua tàu công-ten-nơ"
    ]
  },
  {
    group:"Nghị định", tag:"Sửa đổi, bổ sung",
    title:"Sửa đổi, bổ sung một số điều của Nghị định 26/2019/NĐ-CP",
    code:"Nghị định 37/2024/NĐ-CP",
    date:"Ban hành 04/4/2024 — hiệu lực từ 19/5/2024",
    agency:"Chính phủ",
    status:"Đang áp dụng (một phần Phụ lục V bị NĐ 309/2025 tạm ngưng hiệu lực)",
    summary:"Sửa đổi hàng loạt điều kiện, thủ tục cấp phép khai thác và đăng kiểm tàu cá; bổ sung quy định kiểm soát thuỷ sản khai thác vận chuyển bằng tàu công-ten-nơ nhập khẩu vào Việt Nam.",
    points:[]
  },
  {
    group:"Nghị định", tag:"Sửa đổi, bổ sung",
    title:"Sửa đổi, bổ sung một số điều của Nghị định 26/2019/NĐ-CP (đã sửa đổi bởi NĐ 37/2024)",
    code:"Nghị định 309/2025/NĐ-CP",
    date:"Ban hành 29/11/2025",
    agency:"Chính phủ",
    status:"Đang áp dụng",
    summary:"Tạm ngưng hiệu lực quy định về kích thước tối thiểu được phép khai thác của một số loài thuỷ sản sống trong vùng nước tự nhiên tại Phụ lục V (ban hành kèm NĐ 37/2024) cho đến khi có sửa đổi phù hợp; bãi bỏ một số nội dung không còn cần thiết.",
    points:[]
  },
  {
    group:"Nghị định", tag:"Xử phạt vi phạm hành chính",
    title:"Quy định xử phạt vi phạm hành chính trong lĩnh vực thuỷ sản",
    code:"Nghị định 38/2024/NĐ-CP",
    date:"Ban hành 05/4/2024 — hiệu lực từ 20/5/2024",
    agency:"Chính phủ",
    status:"Thay thế Nghị định 42/2019/NĐ-CP",
    summary:"Gồm 62 điều quy định hành vi vi phạm, hình thức và mức xử phạt, biện pháp khắc phục hậu quả trong lĩnh vực thuỷ sản. Mức phạt tối đa với cá nhân là 1 tỷ đồng (tổ chức gấp 2 lần); thời hiệu xử phạt được nâng từ 1 lên 2 năm so với nghị định cũ.",
    points:[
      "Vi phạm về Giấy phép khai thác, thiết bị VMS, nhật ký khai thác",
      "Vi phạm liên quan chống khai thác IUU: khai thác trái phép ở vùng biển nước ngoài",
      "Vi phạm về nhập khẩu, tạm nhập tái xuất thuỷ sản có nguồn gốc khai thác"
    ]
  },
  {
    group:"Thông tư", tag:"Nghiệp vụ khai thác",
    title:"Quy định ghi, nộp báo cáo, nhật ký khai thác thuỷ sản; kiểm tra tàu cá và giám sát sản lượng tại cảng cá; danh sách tàu cá khai thác IUU; xác nhận, chứng nhận nguồn gốc thuỷ sản khai thác",
    code:"Thông tư 81/2025/TT-BNNMT",
    date:"Ban hành năm 2025",
    agency:"Bộ Nông nghiệp và Môi trường",
    status:"Đang áp dụng",
    summary:"Hướng dẫn nghiệp vụ trực tiếp cho chủ tàu, thuyền trưởng: mẫu nhật ký/báo cáo khai thác, quy trình kiểm tra tàu cá rời/cập cảng, xác nhận nguyên liệu và chứng nhận nguồn gốc thuỷ sản khai thác phục vụ công tác chống khai thác IUU.",
    points:[
      "Mẫu Nhật ký khai thác, báo cáo khai thác thuỷ sản",
      "Quy trình kiểm tra hồ sơ và thực tế tàu cá khi rời/cập cảng cá",
      "Danh sách tàu cá khai thác thuỷ sản bất hợp pháp (IUU)"
    ]
  }
];
const FS_GROUPS = ["Tất cả","Luật","Nghị định","Thông tư"];
let currentFsGroup = "Tất cả";

/* =========================================================
   LUẬT HÀNG HẢI — Danh mục văn bản (Luật, Nghị định, Thông tư)
   liên quan đến tàu biển, cảng biển, thuyền viên, hoạt động hàng hải.
   Tổng hợp tham khảo — nên đối chiếu văn bản gốc khi sử dụng chính thức.
========================================================= */
const MARITIME_DOCS = [
  {
    group:"Luật", tag:"Luật gốc",
    title:"Bộ luật Hàng hải Việt Nam",
    code:"Số 95/2015/QH13",
    date:"Quốc hội thông qua 25/11/2015 — hiệu lực từ 01/07/2017",
    agency:"Quốc hội",
    status:"Còn hiệu lực — đã qua nhiều lần sửa đổi, bổ sung",
    summary:"Văn bản luật gốc quy định về tàu biển, thuyền viên, cảng biển, luồng hàng hải, cảng cạn, vận tải biển, an toàn hàng hải, an ninh hàng hải, bảo vệ môi trường và quản lý nhà nước về hàng hải.",
    points:[
      "Chế độ pháp lý của tàu biển: đăng ký, quốc tịch, quyền sở hữu, thế chấp tàu biển",
      "Cảng biển, luồng hàng hải, hoa tiêu hàng hải, hoạt động của tàu thuyền tại cảng",
      "Hợp đồng vận chuyển hàng hoá, hành khách bằng đường biển",
      "Tai nạn đâm va, cứu hộ hàng hải, trách nhiệm dân sự của chủ tàu"
    ]
  },
  {
    group:"Luật", tag:"Luật sửa đổi",
    title:"Luật Quy hoạch (sửa đổi, bổ sung một số điều của Bộ luật Hàng hải Việt Nam)",
    code:"Số 112/2025/QH15",
    date:"Quốc hội thông qua 10/12/2025 — hiệu lực từ 01/03/2026",
    agency:"Quốc hội",
    status:"Đang áp dụng",
    summary:"Là luật sửa đổi gần nhất trong số nhiều luật đã điều chỉnh Bộ luật Hàng hải 2015 (trước đó có Luật số 35/2018/QH14 về quy hoạch, Luật Giá số 16/2023/QH15, Luật số 81/2025/QH15 về Tổ chức Toà án nhân dân), cập nhật các nội dung về quy hoạch kết cấu hạ tầng hàng hải cho đồng bộ với hệ thống pháp luật quy hoạch hiện hành.",
    points:[]
  },
  {
    group:"Nghị định", tag:"Hướng dẫn thi hành",
    title:"Quy định chi tiết một số điều của Bộ luật Hàng hải Việt Nam về quản lý hoạt động hàng hải",
    code:"Nghị định 58/2017/NĐ-CP",
    date:"Ban hành 10/5/2017",
    agency:"Chính phủ",
    status:"Còn hiệu lực — nghị định khung quan trọng nhất hướng dẫn thi hành",
    summary:"Hướng dẫn chi tiết việc đầu tư xây dựng, quản lý khai thác kết cấu hạ tầng hàng hải; hoạt động của cảng biển, luồng hàng hải; hoa tiêu hàng hải; cứu hộ, trục vớt tài sản chìm đắm và các hoạt động hàng hải khác.",
    points:[
      "Thủ tục tàu thuyền vào, rời cảng biển; hoạt động của Cảng vụ hàng hải",
      "Quản lý luồng hàng hải, hoa tiêu hàng hải, hệ thống báo hiệu hàng hải",
      "Cứu hộ hàng hải, trục vớt tài sản chìm đắm"
    ]
  },
  {
    group:"Nghị định", tag:"Đăng ký tàu biển",
    title:"Đăng ký, xoá đăng ký và mua, bán, đóng mới tàu biển",
    code:"Nghị định 171/2016/NĐ-CP",
    date:"Ban hành 27/12/2016",
    agency:"Chính phủ",
    status:"Đã sửa đổi bởi NĐ 86/2020/NĐ-CP và NĐ 247/2025/NĐ-CP",
    summary:"Quy định điều kiện, hồ sơ, trình tự đăng ký tàu biển vào Sổ đăng ký tàu biển quốc gia Việt Nam; đăng ký thế chấp, xoá đăng ký tàu biển; mua, bán và đóng mới tàu biển.",
    points:[]
  },
  {
    group:"Nghị định", tag:"Phân loại cảng biển",
    title:"Quy định về tiêu chí phân loại cảng biển",
    code:"Nghị định 76/2021/NĐ-CP",
    date:"Ban hành 28/7/2021",
    agency:"Chính phủ",
    status:"Đang áp dụng",
    summary:"Quy định các tiêu chí để phân loại cảng biển Việt Nam (cảng biển đặc biệt, loại I, loại II, loại III) làm cơ sở cho công tác quy hoạch và quản lý đầu tư kết cấu hạ tầng cảng biển.",
    points:[]
  },
  {
    group:"Nghị định", tag:"Sửa đổi, bổ sung",
    title:"Sửa đổi, bổ sung các nghị định trong lĩnh vực hàng hải",
    code:"Nghị định 34/2025/NĐ-CP",
    date:"Ban hành năm 2025",
    agency:"Chính phủ",
    status:"Đang áp dụng",
    summary:"Sửa đổi, bổ sung đồng bộ nhiều nghị định chuyên ngành hàng hải nhằm phân cấp thẩm quyền và cập nhật thủ tục hành chính cho phù hợp mô hình quản lý sau khi hợp nhất Bộ Giao thông vận tải vào Bộ Xây dựng.",
    points:[]
  },
  {
    group:"Nghị định", tag:"Xử phạt vi phạm hành chính",
    title:"Quy định xử phạt vi phạm hành chính trong lĩnh vực hàng hải",
    code:"Nghị định 142/2017/NĐ-CP",
    date:"Ban hành 11/12/2017 — hiệu lực từ 01/02/2018",
    agency:"Chính phủ",
    status:"Đã sửa đổi bởi NĐ 123/2021/NĐ-CP và NĐ 80/2026/NĐ-CP",
    summary:"Gồm 4 chương, 70 điều quy định hành vi vi phạm, hình thức và mức xử phạt, biện pháp khắc phục hậu quả trong lĩnh vực hàng hải. Thời hiệu xử phạt chung là 1 năm, riêng vi phạm về xây dựng cảng biển, công trình hàng hải và bảo vệ môi trường là 2 năm.",
    points:[
      "Vi phạm về xây dựng, quản lý, khai thác kết cấu hạ tầng hàng hải",
      "Vi phạm quy định về hoạt động của tàu thuyền tại cảng biển",
      "Vi phạm về đăng ký tàu thuyền, bố trí thuyền viên, chứng chỉ chuyên môn"
    ]
  },
  {
    group:"Thông tư", tag:"Thuyền viên",
    title:"Quy định về tiêu chuẩn, chứng chỉ chuyên môn, đào tạo, huấn luyện thuyền viên và định biên an toàn tối thiểu của tàu biển Việt Nam",
    code:"Thông tư 20/2023/TT-BGTVT",
    date:"Ban hành năm 2023 — hiệu lực từ 01/9/2023",
    agency:"Bộ Xây dựng (trước đây Bộ Giao thông vận tải)",
    status:"Đang áp dụng — đang có dự thảo thông tư thay thế",
    summary:"Gồm 5 chương, 70 điều quy định tiêu chuẩn chuyên môn, chứng chỉ chuyên môn của thuyền viên, việc đào tạo, huấn luyện thuyền viên và khung định biên an toàn tối thiểu đối với tàu biển, tàu biển công vụ đăng ký tại Việt Nam.",
    points:[
      "Tiêu chuẩn và chứng chỉ chuyên môn theo từng chức danh thuyền viên",
      "Khung định biên an toàn tối thiểu bộ phận boong, bộ phận máy",
      "Thời gian thực tập, đi biển bắt buộc để cấp chứng chỉ chuyên môn"
    ]
  }
];
const MT_GROUPS = ["Tất cả","Luật","Nghị định","Thông tư"];
let currentMtGroup = "Tất cả";


/* =========================================================
   NHẬP CÂU HỎI HÀNG LOẠT (Excel / Google Sheet) — tiện ích
========================================================= */

// Bộ phân tích CSV đơn giản (hỗ trợ ô có dấu phẩy/ngoặc kép/ xuống dòng bên trong)
function parseCSV(text){
  const rows = [];
  let row = [], field = '', inQuotes = false;
  for (let i=0; i<text.length; i++){
    const c = text[i];
    if (inQuotes){
      if (c === '"'){
        if (text[i+1] === '"'){ field += '"'; i++; }
        else { inQuotes = false; }
      } else { field += c; }
    } else {
      if (c === '"'){ inQuotes = true; }
      else if (c === ','){ row.push(field); field=''; }
      else if (c === '\n'){ row.push(field); rows.push(row); row=[]; field=''; }
      else if (c === '\r'){ /* bỏ qua, \n sẽ theo sau */ }
      else { field += c; }
    }
  }
  if (field.length>0 || row.length>0){ row.push(field); rows.push(row); }
  return rows;
}

function extractSheetIdAndGid(url){
  const idMatch = url.match(/\/d\/([a-zA-Z0-9-_]+)/);
  const gidMatch = url.match(/[#&]gid=([0-9]+)/);
  return { id: idMatch ? idMatch[1] : null, gid: gidMatch ? gidMatch[1] : "0" };
}
function buildSheetCsvUrl(id, gid){
  return `https://docs.google.com/spreadsheets/d/${id}/export?format=csv&gid=${gid}`;
}

// Chuyển các dòng dữ liệu thô (mảng-của-mảng) thành câu hỏi trắc nghiệm, bỏ qua dòng tiêu đề/dòng lỗi
function rowsToQuizDrafts(rows){
  const drafts = [], errors = [];
  (rows||[]).forEach((row, idx)=>{
    if (!row || row.every(c=>!String(c==null?'':c).trim())) return; // dòng trống
    const cells = row.map(v=>String(v==null?'':v).trim());
    const [q,a,b,c,d,correctLetter,explain] = cells;
    if (idx===0 && !/^[ABCDabcd]$/.test(correctLetter||'')){
      return; // có vẻ là dòng tiêu đề -> bỏ qua
    }
    if (!q || !a || !b || !c || !d || !/^[ABCDabcd]$/.test(correctLetter||'')){
      errors.push(`Dòng ${idx+1}: thiếu dữ liệu hoặc "Đáp án đúng" không hợp lệ (phải là A/B/C/D).`);
      return;
    }
    const correctIdx = "ABCD".indexOf(correctLetter.toUpperCase());
    drafts.push({ id:'q-'+Date.now()+'-'+idx+'-'+Math.floor(Math.random()*1000), prompt:q, options:[a,b,c,d], correct:correctIdx, explain: explain||"" });
  });
  return { drafts, errors };
}

// Tải thư viện đọc/ghi Excel (SheetJS) từ CDN khi cần, thử lần lượt vài nguồn để tăng độ tin cậy
function loadScriptOnce(url){
  return new Promise((resolve, reject)=>{
    const already = Array.from(document.querySelectorAll('script[data-dyn-src]')).find(s=>s.getAttribute('data-dyn-src')===url);
    if (already){ resolve(); return; }
    const s = document.createElement('script');
    s.src = url; s.async = true; s.setAttribute('data-dyn-src', url);
    s.onload = ()=>resolve();
    s.onerror = ()=>reject(new Error('Không tải được: '+url));
    document.head.appendChild(s);
  });
}
const XLSX_CDN_CANDIDATES = [
  'https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js',
  'https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js',
  'https://unpkg.com/xlsx@0.18.5/dist/xlsx.full.min.js'
];
async function ensureXLSX(){
  if (window.XLSX) return true;
  let lastErr = null;
  for (const url of XLSX_CDN_CANDIDATES){
    try{ await loadScriptOnce(url); if (window.XLSX) return true; }catch(e){ lastErr = e; }
  }
  throw new Error('Không tải được thư viện đọc Excel (cần kết nối Internet). ' + (lastErr?lastErr.message:''));
}

/* =========================================================
   LƯU TRỮ KẾT QUẢ ÔN TẬP (tách riêng khỏi nội dung quản trị)
========================================================= */
/* =========================================================
   LƯU TẠM PHIÊN LÀM BÀI ÔN TẬP (localStorage của trình duyệt)
   Mục đích: nếu người dùng đang làm bài mà lỡ tải lại trang,
   mất mạng, hoặc chuyển sang mục khác (COLREG72/Thuỷ sản/Hàng hải
   nay là các file .html riêng) rồi quay lại, bài làm dở vẫn được
   khôi phục đúng câu đang làm, điểm và thời gian còn lại — không
   bắt làm lại từ đầu. Dùng chung 1 khoá vì cả 3 mục hiện đang
   dùng chung một bộ câu hỏi/luồng nộp bài.
========================================================= */
const QUIZ_SESSION_KEY = "colreg-quiz-session";
function saveQuizSessionToStorage(){
  if (!quizTaker || quizFinished){ clearQuizSessionStorage(); return; }
  try{
    localStorage.setItem(QUIZ_SESSION_KEY, JSON.stringify({
      quizTaker, quizSessionQuestions, quizIndex, quizScore, quizSelected,
      quizDeadline, quizAutoSubmitted, quizLoadError
    }));
  }catch(e){ /* localStorage có thể bị chặn (chế độ ẩn danh...) — bỏ qua */ }
}
function clearQuizSessionStorage(){
  try{ localStorage.removeItem(QUIZ_SESSION_KEY); }catch(e){ /* ignore */ }
}
function restoreQuizSessionFromStorage(){
  let raw;
  try{ raw = localStorage.getItem(QUIZ_SESSION_KEY); }catch(e){ return false; }
  if (!raw) return false;
  let s;
  try{ s = JSON.parse(raw); }catch(e){ clearQuizSessionStorage(); return false; }
  if (!s || !s.quizTaker || !s.quizSessionQuestions || !s.quizSessionQuestions.length) return false;
  quizTaker = s.quizTaker;
  quizSessionQuestions = s.quizSessionQuestions;
  quizIndex = s.quizIndex || 0;
  quizScore = s.quizScore || 0;
  quizSelected = (typeof s.quizSelected === 'number') ? s.quizSelected : null;
  quizDeadline = s.quizDeadline || null;
  quizAutoSubmitted = !!s.quizAutoSubmitted;
  quizLoadError = s.quizLoadError || '';
  quizFinished = false;
  quizLoadingQuestions = false;
  if (quizDeadline && Date.now() >= quizDeadline){
    // Hết giờ trong lúc người dùng vắng mặt/chuyển trang -> tự nộp bài
    quizFinished = true;
    quizAutoSubmitted = true;
    submitQuizResult();
    clearQuizSessionStorage();
  } else if (quizDeadline){
    resumeQuizTimer();
  }
  return true;
}
function resumeQuizTimer(){
  clearQuizTimer();
  updateQuizTimerDisplay();
  quizTimerInterval = setInterval(()=>{
    const remain = quizDeadline - Date.now();
    if (remain <= 0){
      clearQuizTimer();
      if (!quizFinished && quizTaker){
        quizFinished = true;
        quizAutoSubmitted = true;
        submitQuizResult();
        clearQuizSessionStorage();
        if (currentView==='quiz' || currentView==='fisheries-quiz' || currentView==='maritime-quiz') renderView();
      }
      return;
    }
    updateQuizTimerDisplay();
  }, 1000);
}

const RESULTS_KEY = "colreg-quiz-results";
let QUIZ_RESULTS = [];

async function loadQuizResults(){
  if (!window.storage) return QUIZ_RESULTS;
  try{
    const res = await window.storage.get(RESULTS_KEY, true);
    if (res && res.value) return JSON.parse(res.value);
    return [];
  }catch(e){ return []; }
}
async function appendQuizResult(record){
  if (!window.storage){ QUIZ_RESULTS.push(record); return; }
  try{
    const current = await loadQuizResults();
    current.push(record);
    await window.storage.set(RESULTS_KEY, JSON.stringify(current), true);
    QUIZ_RESULTS = current;
  }catch(e){ QUIZ_RESULTS.push(record); }
}
async function clearQuizResultsStorage(){
  QUIZ_RESULTS = [];
  if (window.storage){
    try{ await window.storage.set(RESULTS_KEY, JSON.stringify([]), true); }catch(e){ /* ignore */ }
  }
}

/* =========================================================
   TIỆN ÍCH LƯU TRỮ (window.storage với dự phòng bộ nhớ tạm)
========================================================= */
const STORAGE_KEY = "colreg-app-data";
let storageAvailable = true;
let memoryFallback = null;

function deepClone(o){ return JSON.parse(JSON.stringify(o)); }

function normalizeScenarios(list){
  return (list||[]).map(sc=>{
    let sigs = sc.soundSignals;
    if (!Array.isArray(sigs)){
      sigs = sc.soundSignal ? [sc.soundSignal] : [];
    }
    sc.soundSignals = sigs.map(s => (typeof s === 'string') ? {text:s, audioUrl:""} : {text:(s&&s.text)||"", audioUrl:(s&&s.audioUrl)||""});
    delete sc.soundSignal;
    return sc;
  });
}

async function loadAppData(){
  const fallbackData = { rules:deepClone(DEFAULT_RULES), scenarios:normalizeScenarios(deepClone(DEFAULT_SCENARIOS)), quiz:deepClone(DEFAULT_QUIZ), settings:deepClone(DEFAULT_SETTINGS) };
  if (!window.storage){ storageAvailable=false; memoryFallback = fallbackData; return fallbackData; }
  try{
    const res = await window.storage.get(STORAGE_KEY, true);
    if (res && res.value){
      const parsed = JSON.parse(res.value);
      const mergedSettings = Object.assign({}, fallbackData.settings, parsed.settings||{});
      if (!mergedSettings.resultsWebhookUrl){ mergedSettings.resultsWebhookUrl = fallbackData.settings.resultsWebhookUrl; }
      if (!mergedSettings.bannerImages || !mergedSettings.bannerImages.length){ mergedSettings.bannerImages = fallbackData.settings.bannerImages; }
      if (!mergedSettings.quizSheetUrl){ mergedSettings.quizSheetUrl = fallbackData.settings.quizSheetUrl; }
      if (!mergedSettings.quizSheetProxyUrl){ mergedSettings.quizSheetProxyUrl = fallbackData.settings.quizSheetProxyUrl; }
      if (!mergedSettings.logoImageUrl){ mergedSettings.logoImageUrl = fallbackData.settings.logoImageUrl; }
      if (!mergedSettings.quizRandomCount){ mergedSettings.quizRandomCount = fallbackData.settings.quizRandomCount; }
      return {
        rules: parsed.rules && parsed.rules.length ? parsed.rules : fallbackData.rules,
        scenarios: normalizeScenarios(parsed.scenarios && parsed.scenarios.length ? parsed.scenarios : fallbackData.scenarios),
        quiz: parsed.quiz && parsed.quiz.length ? parsed.quiz : fallbackData.quiz,
        settings: mergedSettings
      };
    }
    return fallbackData;
  }catch(e){
    // key not found yet -> seed it
    try{ await window.storage.set(STORAGE_KEY, JSON.stringify(fallbackData), true); }catch(e2){ storageAvailable=false; }
    return fallbackData;
  }
}

async function persistAppData(){
  if (!storageAvailable || !window.storage){ memoryFallback = DATA; return false; }
  try{
    await window.storage.set(STORAGE_KEY, JSON.stringify(DATA), true);
    return true;
  }catch(e){
    storageAvailable = false;
    memoryFallback = DATA;
    return false;
  }
}

/* =========================================================
   TRẠNG THÁI ỨNG DỤNG
========================================================= */
let DATA = null;
let isLoggedIn = false;
let currentView = (typeof INITIAL_VIEW !== 'undefined' && INITIAL_VIEW) ? INITIAL_VIEW : "home";
let currentPart = "A";
let currentScenarioId = null;
let quizIndex = 0, quizScore = 0, quizSelected = null, quizFinished = false;

/* =========================================================
   BIỂU TƯỢNG (SVG nội tuyến, stroke=currentColor)
========================================================= */
const ICONS = {
  book:`<path d="M4 5.5C4 4.7 4.7 4 5.5 4H12v16H5.5A1.5 1.5 0 0 1 4 18.5V5.5Z" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/><path d="M20 5.5c0-.8-.7-1.5-1.5-1.5H12v16h6.5c.8 0 1.5-.7 1.5-1.5V5.5Z" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/>`,
  radar:`<circle cx="12" cy="12" r="8.4" fill="none" stroke="currentColor" stroke-width="1.5"/><circle cx="12" cy="12" r="4.6" fill="none" stroke="currentColor" stroke-width="1.2" opacity="0.6"/><line x1="12" y1="12" x2="18.3" y2="7.2" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/><circle cx="15.5" cy="15" r="1.3" fill="currentColor"/>`,
  quiz:`<circle cx="12" cy="12" r="8.6" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M9.3 9.6c.2-1.4 1.3-2.3 2.7-2.3 1.4 0 2.5.9 2.5 2.1 0 1.5-1.6 1.7-2.2 2.9-.2.4-.3.8-.3 1.3" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><circle cx="12" cy="16.6" r="0.9" fill="currentColor"/>`,
  home:`<path d="M4 11.5 12 5l8 6.5" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/><path d="M6.5 10.5V19a1 1 0 0 0 1 1H10v-4.5a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1V20h2.5a1 1 0 0 0 1-1v-8.5" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/>`,
  wave:`<path d="M2 15c2 0 2-3 4-3s2 3 4 3 2-3 4-3 2 3 4 3 2-3 4-3" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><path d="M2 19c2 0 2-3 4-3s2 3 4 3 2-3 4-3 2 3 4 3 2-3 4-3" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" opacity="0.55"/>`,
  edit:`<path d="M4 20h4l10-10-4-4L4 16v4Z" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><path d="M13 5.5 18.5 11" stroke="currentColor" stroke-width="1.6"/>`,
  check:`<path d="M4 12.5 9.5 18 20 6" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"/>`,
  x:`<path d="M6 6l12 12M18 6 6 18" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/>`,
  arrowLeft:`<path d="M15 5 8 12l7 7" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>`,
  plus:`<path d="M12 5v14M5 12h14" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>`,
  trash:`<path d="M5 7h14M9 7V5.2A1.2 1.2 0 0 1 10.2 4h3.6A1.2 1.2 0 0 1 15 5.2V7M7 7l.7 12a1.5 1.5 0 0 0 1.5 1.4h5.6a1.5 1.5 0 0 0 1.5-1.4L17 7" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>`,
  fish:`<path d="M3 12c3.2-4.2 8.4-6.2 13.4-4.2l2.6 4.2-2.6 4.2C11.4 18.2 6.2 16.2 3 12Z" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/><path d="M16.4 8.4 19.5 6v3.2M16.4 15.6l3.1 2.4v-3.2" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/><circle cx="7.6" cy="12" r="0.95" fill="currentColor"/>`,
  anchor:`<circle cx="12" cy="5.3" r="2.1" fill="none" stroke="currentColor" stroke-width="1.6"/><line x1="12" y1="7.4" x2="12" y2="19.5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><line x1="8.2" y1="10" x2="15.8" y2="10" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><path d="M4.8 13.2a7.2 7.2 0 0 0 7.2 7.2 7.2 7.2 0 0 0 7.2-7.2" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>`
};

const EMBLEMS = {
  anchor:`<circle cx="24" cy="10" r="4.2" fill="none" stroke="#DDEFF7" stroke-width="2.6"/><line x1="24" y1="14.2" x2="24" y2="38" stroke="#DDEFF7" stroke-width="2.6" stroke-linecap="round"/><line x1="16" y1="18.5" x2="32" y2="18.5" stroke="#DDEFF7" stroke-width="2.6" stroke-linecap="round"/><path d="M9 26a15 15 0 0 0 15 14 15 15 0 0 0 15-14" fill="none" stroke="#DDEFF7" stroke-width="2.6" stroke-linecap="round"/>`,
  compass:`<circle cx="24" cy="24" r="17" fill="none" stroke="#DDEFF7" stroke-width="2.4"/><path d="M24 10 28 24 24 38 20 24Z" fill="#DDEFF7"/><circle cx="24" cy="24" r="2.4" fill="#0B2E4A"/>`,
  wheel:`<circle cx="24" cy="24" r="16" fill="none" stroke="#DDEFF7" stroke-width="2.4"/><circle cx="24" cy="24" r="5" fill="none" stroke="#DDEFF7" stroke-width="2.2"/>${[0,45,90,135,180,225,270,315].map(a=>{const r1=9,r2=16,rad=a*Math.PI/180;const x1=24+r1*Math.sin(rad),y1=24-r1*Math.cos(rad),x2=24+r2*Math.sin(rad),y2=24-r2*Math.cos(rad);return `<line x1="${x1.toFixed(1)}" y1="${y1.toFixed(1)}" x2="${x2.toFixed(1)}" y2="${y2.toFixed(1)}" stroke="#DDEFF7" stroke-width="2.2" stroke-linecap="round"/>`;}).join("")}`,
  ship:`<path d="M10 28h28l-4 9H14l-4-9Z" fill="none" stroke="#DDEFF7" stroke-width="2.4" stroke-linejoin="round"/><line x1="24" y1="28" x2="24" y2="8" stroke="#DDEFF7" stroke-width="2.4"/><path d="M24 10 32 26H24Z" fill="#DDEFF7" opacity="0.85"/>`
};

function buildEmblemMarkup(){
  const s = DATA.settings;
  if (s.logoImageUrl && s.logoImageUrl.trim()){
    return `<image href="${escapeAttr(s.logoImageUrl.trim())}" x="0" y="0" width="48" height="48" preserveAspectRatio="xMidYMid meet" onerror="this.outerHTML=EMBLEMS.anchor;"/>`;
  }
  return EMBLEMS[s.emblem] || EMBLEMS.anchor;
}

function escapeHtml(str){
  return String(str==null?"":str).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
function escapeAttr(str){ return escapeHtml(str); }

function showToast(msg){
  const t = document.getElementById("toast");
  t.textContent = msg;
  t.classList.add("show");
  clearTimeout(showToast._tm);
  showToast._tm = setTimeout(()=>t.classList.remove("show"), 2600);
}

/* =========================================================
   BIỂU ĐỒ RA-ĐA / TÌNH HUỐNG (SVG)
========================================================= */
const ROLE_COLOR = { giveway:"#D6524A", standon:"#2F9E68", both:"#DB8F2E", neutral:"#BFE3F0", caution:"#E7B559" };
const ROLE_LABEL = { giveway:"Tàu nhường đường", standon:"Tàu giữ hướng", both:"Cùng phải nhường đường", neutral:"Trung lập", caution:"Cần chú ý" };

function shipIconSVG(vessel, size){
  size = size || 1;
  const color = ROLE_COLOR[vessel.role] || "#BFE3F0";
  const stroke = "#082238";
  if (vessel.imageUrl && vessel.imageUrl.trim()){
    const w=34*size, h=34*size;
    return `<g transform="translate(${vessel.x},${vessel.y}) rotate(${vessel.heading})">
      <image href="${escapeAttr(vessel.imageUrl.trim())}" x="${-w/2}" y="${-h/2}" width="${w}" height="${h}" preserveAspectRatio="xMidYMid meet"/>
    </g>`;
  }
  if (vessel.radarOnly){
    return `<g transform="translate(${vessel.x},${vessel.y})" class="radar-blip">
      <circle r="10" fill="none" stroke="${color}" stroke-width="1.6" stroke-dasharray="3 3"/>
      <circle r="3" fill="${color}"/>
    </g>`;
  }
  let extra = "";
  if (vessel.type === "sail"){
    extra = `<path d="M0,-14 L0,-30 L7,-15 Z" fill="#F6FBFD" stroke="${stroke}" stroke-width="1" opacity="0.92"/>`;
  } else if (vessel.type === "fishing"){
    extra = `<line x1="-5" y1="2" x2="-14" y2="10" stroke="${stroke}" stroke-width="1.4"/><line x1="5" y1="2" x2="14" y2="10" stroke="${stroke}" stroke-width="1.4"/>`;
  } else if (vessel.type === "restricted"){
    extra = `<circle cx="0" cy="-22" r="3" fill="${ROLE_COLOR.giveway}" stroke="${stroke}" stroke-width="0.8"/><circle cx="0" cy="-15" r="3" fill="${ROLE_COLOR.giveway}" stroke="${stroke}" stroke-width="0.8"/>`;
  }
  const hull = `<path d="M0,-16 L5.5,-4 L5.5,12 L-5.5,12 L-5.5,-4 Z" fill="${color}" stroke="${stroke}" stroke-width="1.3" stroke-linejoin="round"/>`;
  return `<g transform="translate(${vessel.x},${vessel.y}) rotate(${vessel.heading})">${extra}${hull}</g>`;
}

function headingLineSVG(vessel, len){
  len = len || 60;
  const rad = vessel.heading*Math.PI/180;
  const x2 = vessel.x + len*Math.sin(rad);
  const y2 = vessel.y - len*Math.cos(rad);
  return `<line x1="${vessel.x}" y1="${vessel.y}" x2="${x2}" y2="${y2}" stroke="${ROLE_COLOR[vessel.role]||'#BFE3F0'}" stroke-width="1.4" stroke-dasharray="4 4" opacity="0.75"/>`;
}

function turnArrowSVG(vessel){
  // small curved arrow near bow indicating turn to starboard (own right)
  const rad = vessel.heading*Math.PI/180;
  const bowX = vessel.x + 20*Math.sin(rad), bowY = vessel.y - 20*Math.cos(rad);
  const a0 = vessel.heading+20, a1 = vessel.heading+95;
  const r = 16;
  const p0x = bowX + r*Math.sin(a0*Math.PI/180), p0y = bowY - r*Math.cos(a0*Math.PI/180);
  const p1x = bowX + r*Math.sin(a1*Math.PI/180), p1y = bowY - r*Math.cos(a1*Math.PI/180);
  return `<g opacity="0.95">
    <path d="M${p0x.toFixed(1)},${p0y.toFixed(1)} A${r},${r} 0 0 1 ${p1x.toFixed(1)},${p1y.toFixed(1)}" fill="none" stroke="#E7B559" stroke-width="2.2" stroke-linecap="round" marker-end="url(#arrowHead)"/>
  </g>`;
}

function overtakingSectorSVG(vessel){
  // 135 deg sector centered on dead-astern of vessel heading
  const cx=vessel.x, cy=vessel.y, R=95;
  const astern = vessel.heading+180;
  const a0 = astern-67.5, a1 = astern+67.5;
  const pt = a => [cx + R*Math.sin(a*Math.PI/180), cy - R*Math.cos(a*Math.PI/180)];
  const [x0,y0]=pt(a0), [x1,y1]=pt(a1);
  return `<path d="M${cx},${cy} L${x0.toFixed(1)},${y0.toFixed(1)} A${R},${R} 0 0 1 ${x1.toFixed(1)},${y1.toFixed(1)} Z" fill="#D6524A" opacity="0.13" stroke="#D6524A" stroke-width="1.2" stroke-dasharray="5 4"/>`;
}

function envArrowSVG(cx,cy,dir,color,label,dashed){
  const rad=dir*Math.PI/180, len=26;
  const x2=cx+len*Math.sin(rad), y2=cy-len*Math.cos(rad);
  return `<g>
    <line x1="${cx}" y1="${cy}" x2="${x2.toFixed(1)}" y2="${y2.toFixed(1)}" stroke="${color}" stroke-width="2.2" ${dashed?'stroke-dasharray="2 3"':''} marker-end="url(#${dashed?'arrowHeadWind':'arrowHeadCurrent'})"/>
  </g>`;
}

function radarSceneSVG(sc){
  const cx=210, cy=210;
  let out = `<svg viewBox="0 0 420 420" xmlns="http://www.w3.org/2000/svg" style="width:100%;height:auto;display:block;">
  <defs>
    <marker id="arrowHeadCurrent" markerWidth="8" markerHeight="8" refX="4" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 Z" fill="#6FC7E8"/></marker>
    <marker id="arrowHeadWind" markerWidth="8" markerHeight="8" refX="4" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 Z" fill="#E7B559"/></marker>
    <marker id="arrowHead" markerWidth="7" markerHeight="7" refX="3.5" refY="3.5" orient="auto"><path d="M0,0 L7,3.5 L0,7 Z" fill="#E7B559"/></marker>
  </defs>`;

  if (sc.showFog){
    out += `<circle cx="${cx}" cy="${cy}" r="195" fill="url(#fogGrad)"/><radialGradient id="fogGrad" cx="50%" cy="50%" r="60%"><stop offset="0%" stop-color="#F6FBFD" stop-opacity="0.14"/><stop offset="100%" stop-color="#F6FBFD" stop-opacity="0.32"/></radialGradient>`;
  }

  if (sc.showChannel){
    out += `<path d="M40,380 C120,260 140,160 260,20" fill="none" stroke="#6FC7E8" stroke-width="2" opacity="0.55"/>
    <path d="M120,400 C190,270 220,150 340,40" fill="none" stroke="#6FC7E8" stroke-width="2" opacity="0.55"/>
    <path d="M80,390 C155,265 180,155 300,30" fill="none" stroke="#DDEFF7" stroke-width="1" stroke-dasharray="6 6" opacity="0.4"/>`;
  } else {
    [65,130,195].forEach((r,i)=>{
      out += `<circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="#DDEFF7" stroke-width="1" opacity="0.16"/>`;
      out += `<text x="${cx+4}" y="${cy-r+12}" fill="#DDEFF7" opacity="0.4" font-size="9" font-family="-apple-system, Segoe UI, Arial, sans-serif">${i+1} hải lý</text>`;
    });
    for(let a=0;a<360;a+=30){
      const rad=a*Math.PI/180, x1=cx+185*Math.sin(rad), y1=cy-185*Math.cos(rad), x2=cx+195*Math.sin(rad), y2=cy-195*Math.cos(rad);
      out += `<line x1="${x1.toFixed(1)}" y1="${y1.toFixed(1)}" x2="${x2.toFixed(1)}" y2="${y2.toFixed(1)}" stroke="#DDEFF7" stroke-width="1" opacity="0.3"/>`;
    }
    const dirs=[["B",0],["Đ",90],["N",180],["T",270]];
    dirs.forEach(([lab,a])=>{
      const rad=a*Math.PI/180, x=cx+172*Math.sin(rad), y=cy-172*Math.cos(rad);
      out += `<text x="${x}" y="${y}" fill="#8FCBE4" font-size="12" font-weight="700" text-anchor="middle" dominant-baseline="middle" font-family="Arial, Helvetica, sans-serif">${lab}</text>`;
    });
  }

  if (sc.showOvertakingSector==="own") out += overtakingSectorSVG(sc.ownShip);
  if (sc.showOvertakingSector==="target") out += overtakingSectorSVG(sc.targetShip);

  out += `<line x1="${sc.ownShip.x}" y1="${sc.ownShip.y}" x2="${sc.targetShip.x}" y2="${sc.targetShip.y}" stroke="#DDEFF7" stroke-width="1" stroke-dasharray="3 5" opacity="0.4"/>`;

  out += headingLineSVG(sc.ownShip);
  out += headingLineSVG(sc.targetShip);
  out += shipIconSVG(sc.ownShip);
  out += shipIconSVG(sc.targetShip);

  if (sc.showTurnArrows){
    out += turnArrowSVG(sc.ownShip);
    if (sc.ownShip.role==="both") out += turnArrowSVG(sc.targetShip);
  }

  const labelFor = (v)=>`<text x="${v.x}" y="${v.y+28}" text-anchor="middle" fill="#F6FBFD" font-size="11" font-weight="700" font-family="-apple-system, Segoe UI, Arial, sans-serif">${escapeHtml(v.name)}</text>`;
  out += labelFor(sc.ownShip);
  out += labelFor(sc.targetShip);

  const env = sc.environment||{};
  if (env.showCurrent){
    out += envArrowSVG(38,38,env.currentDir||0,"#6FC7E8","Dòng chảy",false);
    out += `<text x="50" y="34" fill="#6FC7E8" font-size="9.5" font-family="-apple-system, Segoe UI, Arial, sans-serif">Dòng chảy ${env.currentDir||0}° / ${env.currentSpeed||0} hl/h</text>`;
  }
  if (env.showWind){
    out += envArrowSVG(38,80,env.windDir||0,"#E7B559",'Gió',true);
    out += `<text x="50" y="84" fill="#E7B559" font-size="9.5" font-family="-apple-system, Segoe UI, Arial, sans-serif">Gió ${env.windDir||0}° / ${env.windSpeed||0} hải lý/giờ</text>`;
  }

  out += `</svg>`;
  return out;
}

/* =========================================================
   TIỆN ÍCH ICON / SỐ
========================================================= */
function iconSvg(name,size){ size=size||22; return `<svg viewBox="0 0 24 24" width="${size}" height="${size}" style="display:block;">${ICONS[name]||''}</svg>`; }
function iconSpan(name){ return `<svg viewBox="0 0 24 24" width="13" height="13" style="display:inline-block;vertical-align:-2px;margin-right:3px;">${ICONS[name]||''}</svg>`; }
function signalRowHTML(text, audioUrl){
  return `<div class="signal-row">
    <input type="text" class="signal-input" value="${escapeAttr(text||'')}" placeholder="Nhập tín hiệu còi...">
    <input type="text" class="signal-audio-input" value="${escapeAttr(audioUrl||'')}" placeholder="URL âm thanh (không bắt buộc)">
    <button type="button" class="btn btn-ghost btn-sm" data-test-signal-audio title="Thử phát âm thanh">▶ Thử</button>
    <button type="button" class="btn btn-ghost btn-sm" data-remove-signal title="Xoá tín hiệu này">${iconSpan('x')}</button>
  </div>`;
}
function clampNum(v,min,max,fallback){ if(isNaN(v)) return fallback; return Math.min(max,Math.max(min,v)); }
function norm360(v,fallback){ if(isNaN(v)) return fallback; return ((Math.round(v)%360)+360)%360; }

/* =========================================================
   TRẠNG THÁI GIAO DIỆN CHỈNH SỬA
========================================================= */
let settingsEditOpen = false;
let scenarioEditOpen = false;
let editingRuleId = null;
let quizManageMode = false;
let editingQuizId = null;
let quizTaker = null; // {name, birthYear} — bắt buộc điền trước khi làm bài ôn tập
let quizDeadline = null;      // mốc thời gian (ms) khi hết giờ làm bài
let quizTimerInterval = null; // id của setInterval đếm ngược
let quizAutoSubmitted = false; // true nếu bài bị tự động nộp do hết giờ
let quizSessionQuestions = null; // bộ câu hỏi (rút ngẫu nhiên) dùng cho LƯỢT làm bài hiện tại
let quizLoadingQuestions = false; // đang tải câu hỏi từ Google Sheet
let quizLoadError = ''; // thông báo lỗi (nếu có) khi tải câu hỏi từ Google Sheet
let bannerCarouselIndex = 0;
let bannerCarouselInterval = null;
let webhookPanelOpen = false;
let importPanelOpen = false;
let resultsViewOpen = false;
let pendingImportDrafts = [];
let pendingImportErrors = [];
let importStatusMessage = "";
let quizImportSheetUrlDraft = "";

/* =========================================================
   TRANG CHỦ
========================================================= */
function bannerImageRowHTML(url, caption){
  return `<div class="signal-row">
    <input type="text" class="banner-img-url-input" value="${escapeAttr(url||'')}" placeholder="URL ảnh (https://...)">
    <input type="text" class="banner-img-caption-input" value="${escapeAttr(caption||'')}" placeholder="Chú thích (không bắt buộc)">
    <button type="button" class="btn btn-ghost btn-sm" data-remove-banner-image title="Xoá ảnh này">${iconSpan('x')}</button>
  </div>`;
}
function bannerCarouselHTML(){
  const imgs = DATA.settings.bannerImages||[];
  if (!imgs.length) return '';
  const first = imgs[0];
  return `<div class="banner-carousel">
    <img id="banner-carousel-img" class="banner-carousel-img" src="${escapeAttr(first.url)}" alt="${escapeAttr(first.caption||'')}" onerror="this.closest('.banner-carousel').style.display='none'">
    ${imgs.length>1?`
    <button type="button" class="banner-carousel-arrow prev" data-banner-prev aria-label="Ảnh trước">‹</button>
    <button type="button" class="banner-carousel-arrow next" data-banner-next aria-label="Ảnh sau">›</button>
    <div class="banner-carousel-dots">${imgs.map((_,i)=>`<button type="button" class="banner-carousel-dot ${i===0?'active':''}" data-banner-dot="${i}" aria-label="Ảnh ${i+1}"></button>`).join('')}</div>`:''}
  </div>`;
}
function updateBannerCarouselDisplay(){
  const imgs = DATA.settings.bannerImages||[];
  const imgEl = document.getElementById('banner-carousel-img');
  if (!imgEl || !imgs.length) return;
  if (bannerCarouselIndex>=imgs.length) bannerCarouselIndex = 0;
  const img = imgs[bannerCarouselIndex];
  imgEl.style.opacity = '0';
  setTimeout(()=>{
    imgEl.src = img.url;
    imgEl.alt = img.caption||'';
    imgEl.style.opacity = '1';
  }, 220);
  document.querySelectorAll('.banner-carousel-dot').forEach((d,i)=>d.classList.toggle('active', i===bannerCarouselIndex));
}
function startBannerCarousel(){
  clearInterval(bannerCarouselInterval); bannerCarouselInterval = null;
  const imgs = DATA.settings.bannerImages||[];
  if (imgs.length<=1) return;
  bannerCarouselInterval = setInterval(()=>{
    bannerCarouselIndex = (bannerCarouselIndex+1) % imgs.length;
    updateBannerCarouselDisplay();
  }, 4500);
}
function heroRadarSVG(){
  return `<svg class="hero-radar" viewBox="0 0 420 420" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <defs><linearGradient id="sweepGrad" x1="0" y1="1" x2="1" y2="0">
      <stop offset="0%" stop-color="#6FC7E8" stop-opacity="0.55"/><stop offset="100%" stop-color="#6FC7E8" stop-opacity="0"/>
    </linearGradient></defs>
    <circle cx="210" cy="210" r="200" fill="none" stroke="#DDEFF7" stroke-width="1" opacity="0.22"/>
    <circle cx="210" cy="210" r="140" fill="none" stroke="#DDEFF7" stroke-width="1" opacity="0.18"/>
    <circle cx="210" cy="210" r="70" fill="none" stroke="#DDEFF7" stroke-width="1" opacity="0.16"/>
    <g class="hero-sweep"><path d="M210,210 L210,10 A200,200 0 0 1 350,70 Z" fill="url(#sweepGrad)"/></g>
  </svg>`;
}

function settingsEditPanelHTML(){
  if (!settingsEditOpen) return "";
  const s = DATA.settings;
  return `<div class="edit-card" style="margin-top:20px;">
    <h4>${iconSpan('edit')} Chỉnh giao diện &amp; thương hiệu</h4>
    <div class="form-row-2">
      <div class="form-field"><label>Tên ứng dụng</label><input type="text" id="set-appTitle" value="${escapeAttr(s.appTitle)}"></div>
      <div class="form-field"><label>Phụ đề</label><input type="text" id="set-appSubtitle" value="${escapeAttr(s.appSubtitle)}"></div>
    </div>
    <div class="form-field"><label>Đơn vị quản lý</label><input type="text" id="set-orgName" value="${escapeAttr(s.orgName)}"></div>
    <div class="form-field"><label>Dòng giới thiệu nhỏ (trên tiêu đề)</label><input type="text" id="set-heroEyebrow" value="${escapeAttr(s.heroEyebrow)}"></div>
    <div class="form-field"><label>Đoạn giới thiệu</label><textarea id="set-heroLead">${escapeHtml(s.heroLead)}</textarea></div>
    <div class="form-field"><label>Nội dung chân trang (Footer)</label><input type="text" id="set-footerText" value="${escapeAttr(s.footerText)}"><small style="display:block;color:var(--ink-soft);font-size:11.5px;margin-top:4px;">Toàn bộ dòng chữ hiển thị ở cuối trang — có thể chỉnh sửa tự do, không phụ thuộc Tên ứng dụng/Đơn vị quản lý.</small></div>
    <div class="form-row-2">
      <div class="form-field"><label>Biểu tượng logo mặc định</label>
        <select id="set-emblem">
          <option value="anchor" ${s.emblem==='anchor'?'selected':''}>Mỏ neo</option>
          <option value="compass" ${s.emblem==='compass'?'selected':''}>La bàn</option>
          <option value="wheel" ${s.emblem==='wheel'?'selected':''}>Bánh lái</option>
          <option value="ship" ${s.emblem==='ship'?'selected':''}>Tàu</option>
        </select>
      </div>
      <div class="form-field"><label>URL ảnh logo tuỳ chỉnh (không bắt buộc)</label><input type="text" id="set-logoUrl" placeholder="https://..." value="${escapeAttr(s.logoImageUrl)}"></div>
    </div>
    <div class="form-field">
      <label>Ảnh banner tự động thay đổi ở đầu trang chủ (không bắt buộc)</label>
      <div id="banner-images-list">
        ${(s.bannerImages||[]).map(img=>bannerImageRowHTML(img.url, img.caption)).join('')}
      </div>
      <button type="button" class="btn btn-ghost btn-sm" data-add-banner-image>${iconSpan('plus')} Thêm ảnh</button>
    </div>
    <div class="edit-actions">
      <button class="btn btn-primary btn-sm" data-save-settings>Lưu thay đổi</button>
      <button class="btn btn-ghost btn-sm" data-cancel-settings>Huỷ</button>
      <button class="btn btn-danger btn-sm" data-reset-defaults style="margin-left:auto;">${iconSpan('trash')} Khôi phục mặc định (xoá mọi chỉnh sửa)</button>
    </div>
  </div>`;
}

function viewHomeHTML(){
  const s = DATA.settings;
  const totalQuiz = (DATA.quiz||[]).length;
  return `<section class="view">
    ${bannerCarouselHTML()}

    <div class="home-intro">
      <h1>Nền tảng đào tạo và ôn tập trực tuyến</h1>
      <p class="lead">Xây dựng nhằm hỗ trợ thuyền viên, học viên hàng hải nắm vững hệ thống pháp luật và quy định liên quan đến hoạt động trên biển — thông qua tra cứu điều luật trực quan, mô phỏng tình huống thực tế và bộ đề ôn luyện trắc nghiệm bám sát nội dung thi. Nội dung được cập nhật liên tục theo ba lĩnh vực trọng tâm bên dưới.</p>
      <div class="home-intro-stats">
        <div><div class="home-intro-stat-num">03</div><div class="home-intro-stat-label">Lĩnh vực pháp luật</div></div>
        <div><div class="home-intro-stat-num">${DATA.rules.length}</div><div class="home-intro-stat-label">Điều quy tắc COLREG72</div></div>
        <div><div class="home-intro-stat-num">${DATA.scenarios.length}</div><div class="home-intro-stat-label">Tình huống mô phỏng</div></div>
        <div><div class="home-intro-stat-num">${totalQuiz}</div><div class="home-intro-stat-label">Câu hỏi ôn luyện</div></div>
      </div>
    </div>

    <div class="section-head">
      <div><span class="section-eyebrow">Nội dung</span></div>
    </div>
    <div class="home-modules-grid">
      <a class="card module-card" href="colreg.html">
        <span class="module-status live">Đang hoạt động</span>
        <div class="icon-wrap">${iconSpan('radar')}</div>
        <h3>COLREG72</h3>
        <p>Quy tắc quốc tế phòng ngừa đâm va tàu thuyền trên biển — học qua mô phỏng tình huống thực tế, tra cứu đầy đủ các điều quy tắc và tự kiểm tra bằng bộ đề trắc nghiệm.</p>
        <div class="module-tags">
          <span class="module-tag">Nội dung</span><span class="module-tag">Mô phỏng</span><span class="module-tag">Ôn tập</span>
        </div>
        <div class="module-cta">Khám phá COLREG72 →</div>
      </a>

      <a class="card module-card" href="fisheries.html">
        <span class="module-status live">Đang hoạt động</span>
        <div class="icon-wrap">${iconSpan('fish')}</div>
        <h3>Luật Thuỷ sản</h3>
        <p>Hệ thống hoá các quy định về khai thác, bảo vệ nguồn lợi thuỷ sản và quản lý tàu cá theo pháp luật hiện hành, kèm bộ đề tự kiểm tra.</p>
        <div class="module-tags">
          <span class="module-tag">Nội dung</span><span class="module-tag">Ôn tập</span>
        </div>
        <div class="module-cta">Khám phá Luật Thuỷ sản →</div>
      </a>

      <a class="card module-card" href="maritime.html">
        <span class="module-status live">Đang hoạt động</span>
        <div class="icon-wrap">${iconSpan('anchor')}</div>
        <h3>Luật Hàng hải</h3>
        <p>Bộ luật Hàng hải Việt Nam và các văn bản hướng dẫn về tàu biển, cảng biển, thuyền viên và trách nhiệm của các bên liên quan, kèm bộ đề tự kiểm tra.</p>
        <div class="module-tags">
          <span class="module-tag">Nội dung</span><span class="module-tag">Ôn tập</span>
        </div>
        <div class="module-cta">Khám phá Luật Hàng hải →</div>
      </a>
    </div>
  </section>`;
}

/* =========================================================
   TRANG TRỐNG (chưa triển khai nội dung)
========================================================= */
function viewPlaceholderHTML(title, note){
  return `<section class="view">
    <div class="section-head"><div><span class="section-eyebrow">Đang cập nhật</span><h2>${escapeHtml(title)}</h2></div></div>
    <div class="card" style="padding:40px 24px;">
      <div class="empty-note">${escapeHtml(note || 'Nội dung mục này đang được xây dựng và sẽ sớm được cập nhật.')}</div>
    </div>
  </section>`;
}

/* =========================================================
   QUY TẮC
========================================================= */
function ruleEditFormHTML(r){
  return `<div class="edit-card">
    <h4>${iconSpan('edit')} Chỉnh sửa điều luật</h4>
    <div class="form-row-2">
      <div class="form-field"><label>Số điều</label><input type="text" id="rf-${r.id}-num" value="${escapeAttr(r.num)}"></div>
      <div class="form-field"><label>Tiêu đề</label><input type="text" id="rf-${r.id}-title" value="${escapeAttr(r.title)}"></div>
    </div>
    <div class="form-field"><label>Nội dung diễn giải</label><textarea id="rf-${r.id}-body" style="min-height:120px;">${escapeHtml(r.body)}</textarea></div>
    <div class="edit-actions">
      <button class="btn btn-primary btn-sm" data-save-rule="${r.id}">Lưu</button>
      <button class="btn btn-ghost btn-sm" data-cancel-rule>Huỷ</button>
    </div>
  </div>`;
}
function ruleCardHTML(r){
  const editing = editingRuleId===r.id;
  return `<div class="card rule-item">
    <span class="rule-num">${escapeHtml(r.num)}</span>
    ${isLoggedIn?`<button class="btn btn-ghost btn-sm" style="float:right" data-edit-rule="${r.id}">${iconSpan('edit')} ${editing?'Đóng':'Sửa'}</button>`:''}
    <h3>${escapeHtml(r.title)}</h3>
    <div class="rule-body">${escapeHtml(r.body)}</div>
    ${editing?ruleEditFormHTML(r):''}
  </div>`;
}
function viewRulesHTML(){
  const rulesInPart = DATA.rules.filter(r=>r.part===currentPart);
  return `<section class="view">
    ${quizHeroHTML()}
    <div class="section-head"><div><span class="section-eyebrow">Tra cứu</span><h2>Quy tắc COLREG 72</h2></div></div>
    <div class="rules-layout">
      <div class="rules-parts">
        ${PART_ORDER.map(p=>`<button class="part-btn ${p===currentPart?'active':''}" data-part="${p}">${PART_LABELS[p].title}<small>${PART_LABELS[p].sub}</small></button>`).join('')}
      </div>
      <div class="rules-list">
        ${rulesInPart.map(r=>ruleCardHTML(r)).join('') || `<div class="empty-note">Chưa có điều nào trong phần này.</div>`}
      </div>
    </div>
  </section>`;
}

/* =========================================================
   MÔ PHỎNG — DANH SÁCH
========================================================= */
function scenarioTagMeta(roleTag){
  if(roleTag==='giveway') return ['tag-giveway','Tàu ta nhường đường'];
  if(roleTag==='standon') return ['tag-standon','Tàu ta giữ hướng'];
  if(roleTag==='both') return ['tag-both','Cùng nhường đường'];
  if(roleTag==='caution') return ['tag-both','Cần chú ý'];
  return ['tag-neutral','Trung lập'];
}
function scenarioCardHTML(sc){
  const [tagClass,tagLabel] = scenarioTagMeta(sc.roleTag);
  return `<div class="card scenario-card" data-open-scenario="${sc.id}">
    <span class="tag ${tagClass}">${tagLabel}</span>
    <h3>${escapeHtml(sc.title)}</h3>
    <p>${escapeHtml(sc.summary)}</p>
    <div class="rule-ref">${escapeHtml(sc.ruleRef)}</div>
  </div>`;
}
function viewScenariosListHTML(){
  return `<section class="view">
    <div class="section-head">
      <div><span class="section-eyebrow">Thực hành</span><h2>Mô phỏng tình huống tránh va</h2></div>
      ${isLoggedIn?`<button class="btn btn-brass btn-sm" data-add-scenario>${iconSpan('plus')} Thêm tình huống</button>`:''}
    </div>
    <div class="grid-cards">
      ${DATA.scenarios.map(sc=>scenarioCardHTML(sc)).join('') || `<div class="empty-note">Chưa có tình huống nào.</div>`}
    </div>
  </section>`;
}

/* =========================================================
   MÔ PHỎNG — CHI TIẾT + FORM CHỈNH SỬA
========================================================= */
function vesselEditFieldsHTML(sc,key){
  const v = sc[key];
  const label = key==='ownShip' ? 'Tàu ta' : 'Tàu mục tiêu';
  const p = `${sc.id}-${key}`;
  return `<h4 style="margin-top:16px;">${label}</h4>
  <div class="form-row-2">
    <div class="form-field"><label>Tên hiển thị</label><input type="text" id="ef-${p}-name" value="${escapeAttr(v.name)}"></div>
    <div class="form-field"><label>Loại phương tiện</label>
      <select id="ef-${p}-type">${Object.keys(VESSEL_TYPES).map(t=>`<option value="${t}" ${v.type===t?'selected':''}>${VESSEL_TYPES[t].label}</option>`).join('')}</select>
    </div>
  </div>
  <div class="form-row-2">
    <div class="form-field"><label>Vai trò trong tình huống</label>
      <select id="ef-${p}-role">${Object.keys(ROLE_LABEL).map(r=>`<option value="${r}" ${v.role===r?'selected':''}>${ROLE_LABEL[r]}</option>`).join('')}</select>
    </div>
    <div class="form-field"><label>Hướng đi (độ la bàn, 0–359)</label><input type="number" min="0" max="359" id="ef-${p}-heading" value="${v.heading}"></div>
  </div>
  <div class="form-row-2">
    <div class="form-field"><label>Vị trí trên sơ đồ — X (20–400)</label><input type="number" min="20" max="400" id="ef-${p}-x" value="${v.x}"></div>
    <div class="form-field"><label>Vị trí trên sơ đồ — Y (20–400)</label><input type="number" min="20" max="400" id="ef-${p}-y" value="${v.y}"></div>
  </div>
  <div class="form-field"><label>URL ảnh phương tiện tuỳ chỉnh (không bắt buộc, thay thế biểu tượng mặc định)</label><input type="text" id="ef-${p}-img" placeholder="https://..." value="${escapeAttr(v.imageUrl||'')}"></div>`;
}
function scenarioEditFormHTML(sc){
  const env = sc.environment;
  return `<div class="edit-card">
    <h4>${iconSpan('edit')} Chỉnh sửa tình huống</h4>
    <div class="form-row-2">
      <div class="form-field"><label>Tiêu đề</label><input type="text" id="ef-${sc.id}-title" value="${escapeAttr(sc.title)}"></div>
      <div class="form-field"><label>Điều tham chiếu</label><input type="text" id="ef-${sc.id}-ruleRef" value="${escapeAttr(sc.ruleRef)}"></div>
    </div>
    <div class="form-field"><label>Tóm tắt (hiển thị ở danh sách)</label><input type="text" id="ef-${sc.id}-summary" value="${escapeAttr(sc.summary)}"></div>
    <div class="form-field"><label>Mô tả tình huống</label><textarea id="ef-${sc.id}-description">${escapeHtml(sc.description)}</textarea></div>
    <div class="form-field"><label>Hành động cần thực hiện</label><textarea id="ef-${sc.id}-action">${escapeHtml(sc.action)}</textarea></div>
    <div class="form-field">
      <label>Tín hiệu còi (có thể thêm nhiều, mỗi tín hiệu có thể kèm URL âm thanh)</label>
      <div id="signals-list-${sc.id}">
        ${(sc.soundSignals||[]).map(s=>signalRowHTML(s.text, s.audioUrl)).join('')}
      </div>
      <button type="button" class="btn btn-ghost btn-sm" data-add-signal="${sc.id}">${iconSpan('plus')} Thêm tín hiệu còi</button>
    </div>

    ${vesselEditFieldsHTML(sc,'ownShip')}
    ${vesselEditFieldsHTML(sc,'targetShip')}

    <h4 style="margin-top:16px;">Điều kiện môi trường</h4>
    <div class="form-row-2">
      <div class="form-field"><label>Hướng dòng chảy (độ)</label><input type="number" min="0" max="359" id="ef-${sc.id}-currentDir" value="${env.currentDir}"></div>
      <div class="form-field"><label>Tốc độ dòng chảy (hải lý/giờ)</label><input type="number" step="0.1" min="0" id="ef-${sc.id}-currentSpeed" value="${env.currentSpeed}"></div>
    </div>
    <div class="form-row-2">
      <div class="form-field"><label>Hướng gió (độ)</label><input type="number" min="0" max="359" id="ef-${sc.id}-windDir" value="${env.windDir}"></div>
      <div class="form-field"><label>Tốc độ gió (hải lý/giờ)</label><input type="number" step="0.5" min="0" id="ef-${sc.id}-windSpeed" value="${env.windSpeed}"></div>
    </div>
    <div class="form-row-2">
      <div class="form-field"><label>Tầm nhìn xa (mô tả)</label><input type="text" id="ef-${sc.id}-visibility" value="${escapeAttr(env.visibility)}"></div>
      <div class="form-field"><label>Hiển thị dòng chảy?</label>
        <select id="ef-${sc.id}-showCurrent"><option value="1" ${env.showCurrent?'selected':''}>Có</option><option value="0" ${!env.showCurrent?'selected':''}>Không</option></select>
      </div>
    </div>
    <div class="form-field"><label>Hiển thị mũi tên gió?</label>
      <select id="ef-${sc.id}-showWind"><option value="1" ${env.showWind?'selected':''}>Có</option><option value="0" ${!env.showWind?'selected':''}>Không</option></select>
    </div>

    <div class="edit-actions">
      <button class="btn btn-primary btn-sm" data-save-scenario="${sc.id}">Lưu thay đổi</button>
      <button class="btn btn-ghost btn-sm" data-cancel-scenario>Huỷ</button>
      <button class="btn btn-danger btn-sm" data-delete-scenario="${sc.id}" style="margin-left:auto;">${iconSpan('trash')} Xoá tình huống</button>
    </div>
  </div>`;
}
function viewScenarioDetailHTML(id){
  const sc = DATA.scenarios.find(s=>s.id===id);
  if (!sc) return `<section class="view"><button class="back-link" data-back-scenarios>${iconSpan('arrowLeft')} Quay lại danh sách</button><div class="empty-note">Không tìm thấy tình huống.</div></section>`;
  const env = sc.environment;
  return `<section class="view">
    <button class="back-link" data-back-scenarios>${iconSpan('arrowLeft')} Quay lại danh sách</button>
    <div class="card scenario-detail">
      <div class="scenario-detail-head">
        <div><span class="rule-ref">${escapeHtml(sc.ruleRef)}</span><h2 style="margin-top:4px;">${escapeHtml(sc.title)}</h2></div>
        ${isLoggedIn?`<button class="btn btn-brass btn-sm" data-edit-scenario="${sc.id}">${iconSpan('edit')} ${scenarioEditOpen?'Đóng chỉnh sửa':'Chỉnh sửa tình huống'}</button>`:''}
      </div>
      <div class="detail-grid">
        <div>
          <div class="radar-wrap">${radarSceneSVG(sc)}</div>
          <div class="radar-legend">
            <span><span class="legend-dot" style="background:${ROLE_COLOR.giveway}"></span>Nhường đường</span>
            <span><span class="legend-dot" style="background:${ROLE_COLOR.standon}"></span>Giữ hướng</span>
            <span><span class="legend-dot" style="background:${ROLE_COLOR.both}"></span>Cùng nhường</span>
          </div>
          <div class="env-row" style="margin-top:14px;">
            <span>Tầm nhìn xa: ${escapeHtml(env.visibility)}</span>
            ${env.showCurrent?`<span>Dòng chảy: ${env.currentDir}° / ${env.currentSpeed} hải lý/giờ</span>`:''}
            ${env.showWind?`<span>Gió: ${env.windDir}° / ${env.windSpeed} hải lý/giờ</span>`:''}
          </div>
        </div>
        <div>
          <div class="detail-block"><h4>Mô tả tình huống</h4><p>${escapeHtml(sc.description)}</p></div>
          <div class="detail-block"><h4>Hành động cần thực hiện</h4><p>${escapeHtml(sc.action)}</p></div>
          <div class="detail-block"><h4>Tín hiệu còi</h4>${(sc.soundSignals&&sc.soundSignals.length) ? sc.soundSignals.map(s=>{
            const hasAudio = s.audioUrl && s.audioUrl.trim();
            return `<div style="margin-bottom:8px;">${hasAudio
              ? `<button type="button" class="sound-badge" data-play-audio="${escapeAttr(s.audioUrl.trim())}">🔊 ${escapeHtml(s.text)} <span class="play-glyph">▶</span></button>`
              : `<span class="sound-badge">🔊 ${escapeHtml(s.text)}</span>`}</div>`;
          }).join('') : `<p style="font-style:italic;">Chưa có tín hiệu còi được thiết lập cho tình huống này.</p>`}</div>
        </div>
      </div>
      ${(scenarioEditOpen && isLoggedIn) ? scenarioEditFormHTML(sc) : ''}
    </div>
  </section>`;
}

/* =========================================================
   ÔN TẬP — TRẮC NGHIỆM
========================================================= */
function pickRandomQuestions(list, n){
  const arr = (list||[]).slice();
  for (let i = arr.length - 1; i > 0; i--){
    const j = Math.floor(Math.random() * (i + 1));
    const tmp = arr[i]; arr[i] = arr[j]; arr[j] = tmp;
  }
  return arr.slice(0, Math.min(n, arr.length));
}

// Cách 1 — đơn giản, không cần cài thêm gì: tải trực tiếp CSV từ Google Sheet.
// LƯU Ý: trình duyệt đôi khi CHẶN cách này do chính sách CORS của Google (tuỳ từng
// trường hợp/trình duyệt) — nếu gặp, hãy cấu hình thêm "URL Apps Script trung chuyển"
// (Cách 2 bên dưới), vốn không bao giờ bị chặn vì không phải gọi thẳng sang docs.google.com.
async function fetchQuizFromSheetDirect(sheetUrl){
  const { id, gid } = extractSheetIdAndGid(sheetUrl);
  if (!id) throw new Error('Không đọc được ID Google Sheet từ URL đã cấu hình.');
  const csvUrl = buildSheetCsvUrl(id, gid);
  const resp = await fetch(csvUrl);
  if (!resp.ok) throw new Error('HTTP ' + resp.status);
  const text = await resp.text();
  const rows = parseCSV(text);
  const { drafts } = rowsToQuizDrafts(rows);
  return drafts;
}

// Cách 2 — đáng tin cậy hơn (không thể bị chặn bởi CORS, vì dùng kỹ thuật JSONP qua thẻ
// <script>): đọc câu hỏi qua một Google Apps Script Web App trung chuyển do bạn tự triển
// khai trên chính Sheet câu hỏi. Xem hướng dẫn/đoạn mã doGet() đi kèm.
function fetchQuizViaAppsScriptJsonp(proxyUrl){
  return new Promise((resolve, reject) => {
    const cbName = '__quizJsonpCb_' + Date.now() + '_' + Math.floor(Math.random()*100000);
    const script = document.createElement('script');
    const timeoutId = setTimeout(() => { cleanup(); reject(new Error('Hết thời gian chờ phản hồi từ Apps Script (10s).')); }, 10000);
    function cleanup(){
      clearTimeout(timeoutId);
      try{ delete window[cbName]; }catch(e){ window[cbName] = undefined; }
      if (script.parentNode) script.parentNode.removeChild(script);
    }
    window[cbName] = function(data){
      cleanup();
      try{
        const list = (data && Array.isArray(data.questions)) ? data.questions : [];
        const drafts = list.map(q => {
          const letter = String(q.correct==null?'':q.correct).trim().toUpperCase();
          const correctIdx = "ABCD".indexOf(letter) !== -1 ? "ABCD".indexOf(letter) : (typeof q.correct==='number'?q.correct:0);
          return {
            id: 'sheet-'+Math.random().toString(36).slice(2),
            prompt: String(q.prompt||q.question||'').trim(),
            options: Array.isArray(q.options) ? q.options : [q.a,q.b,q.c,q.d],
            correct: correctIdx,
            explain: String(q.explain||'').trim()
          };
        }).filter(q => q.prompt && q.options && q.options.length===4 && q.options.every(o=>o!=null && String(o).trim()!==''));
        resolve(drafts);
      }catch(e){ reject(e); }
    };
    script.onerror = () => { cleanup(); reject(new Error('Không tải được script từ Apps Script trung chuyển.')); };
    script.src = proxyUrl + (proxyUrl.includes('?') ? '&' : '?') + 'callback=' + cbName;
    document.head.appendChild(script);
  });
}

// Luôn thử lấy câu hỏi MỚI NHẤT trước (Cách 1 rồi tới Cách 2 nếu có cấu hình);
// chỉ dùng ngân hàng câu hỏi cục bộ (DATA.quiz) khi cả hai đều thất bại hoặc chưa cấu hình.
async function loadQuizQuestionsForSession(){
  const sheetUrl = (DATA.settings.quizSheetUrl || '').trim();
  const proxyUrl = (DATA.settings.quizSheetProxyUrl || '').trim();
  const wantCount = DATA.settings.quizRandomCount || 20;
  quizLoadError = '';

  if (sheetUrl){
    try{
      const drafts = await fetchQuizFromSheetDirect(sheetUrl);
      if (drafts.length) return pickRandomQuestions(drafts, wantCount);
      throw new Error('Không tìm thấy câu hỏi hợp lệ trong Google Sheet.');
    }catch(e){
      console.warn('Tải trực tiếp từ Google Sheet thất bại (thường do CORS):', e.message);
      quizLoadError = 'Không tải trực tiếp được từ Google Sheet (thường do trình duyệt chặn CORS).';
    }
  }

  if (proxyUrl){
    try{
      const drafts = await fetchQuizViaAppsScriptJsonp(proxyUrl);
      if (drafts.length){ quizLoadError = ''; return pickRandomQuestions(drafts, wantCount); }
      throw new Error('Apps Script trung chuyển không trả về câu hỏi hợp lệ nào.');
    }catch(e){
      console.warn('Tải qua Apps Script trung chuyển cũng thất bại:', e.message);
      quizLoadError = (quizLoadError?quizLoadError+' ':'') + 'Tải qua Apps Script trung chuyển cũng không thành công: ' + e.message;
    }
  }

  if (quizLoadError) quizLoadError += ' Đang dùng tạm ngân hàng câu hỏi cục bộ.';
  return pickRandomQuestions(DATA.quiz, Math.min(wantCount, DATA.quiz.length));
}

function quizTakerFormInnerHTML(){
  const nowYear = new Date().getFullYear();
  const durMin = DATA.settings.examDurationMinutes || 10;
  const wantCount = DATA.settings.quizRandomCount || 20;
  return `<div class="card quiz-card">
      <p style="margin-bottom:10px;">Vui lòng nhập thông tin trước khi bắt đầu làm bài. Thông tin này sẽ được ghi lại cùng với kết quả bài làm của bạn.</p>
      <p style="margin-bottom:18px;font-size:13px;color:var(--ink-soft);">⏱ Thời gian làm bài: <strong>${durMin} phút</strong> — hết giờ sẽ tự động nộp bài. Mỗi lượt gồm <strong>${wantCount} câu hỏi</strong> được chọn ngẫu nhiên, lấy mới nhất từ ngân hàng câu hỏi.</p>
      <div class="form-field"><label>Họ và tên</label><input type="text" id="taker-name" placeholder="Nguyễn Văn A"></div>
      <div class="form-field"><label>Năm sinh</label><input type="number" id="taker-birthyear" placeholder="1995" min="1940" max="${nowYear}"></div>
      <div class="form-error" id="taker-form-error"></div>
      <button class="btn btn-primary" data-start-quiz>Bắt đầu làm bài</button>
    </div>`;
}
function quizLoadingInnerHTML(){
  return `<div class="card quiz-card" style="text-align:center;padding:40px 20px;">
      <p>Đang tải câu hỏi mới nhất...</p>
    </div>`;
}
function quizActiveInnerHTML(){
  const total = quizSessionQuestions.length;
  const q = quizSessionQuestions[quizIndex];
  return `<div class="card quiz-card">
      ${quizLoadError?`<div class="quiz-explain" style="margin-bottom:14px;border-left:3px solid var(--giveway);">${escapeHtml(quizLoadError)}</div>`:''}
      <div class="quiz-progress" style="display:flex;justify-content:space-between;align-items:center;">
        <span>Câu ${quizIndex+1} / ${total} · Điểm hiện tại: ${quizScore}</span>
        <span class="quiz-timer" id="quiz-timer-display">--:--</span>
      </div>
      <div class="quiz-bar"><div class="quiz-bar-fill" style="width:${(quizIndex/total)*100}%"></div></div>
      <div class="quiz-q">${escapeHtml(q.prompt)}</div>
      ${q.options.map((opt,i)=>{
        let cls='quiz-opt';
        if (quizSelected!==null){ if(i===q.correct) cls+=' correct'; else if(i===quizSelected) cls+=' incorrect'; }
        return `<button class="${cls}" data-quiz-opt="${i}" ${quizSelected!==null?'disabled':''}>${String.fromCharCode(65+i)}. ${escapeHtml(opt)}</button>`;
      }).join('')}
      ${quizSelected!==null?`<div class="quiz-explain"><strong>${quizSelected===q.correct?'Chính xác!':'Chưa đúng.'}</strong> ${escapeHtml(q.explain)}</div>
      <div class="edit-actions"><button class="btn btn-primary btn-sm" data-quiz-next>${quizIndex+1<total?'Câu tiếp theo':'Xem kết quả'}</button></div>`:''}
    </div>`;
}
function quizHeroHTML(){
  const s = DATA.settings;
  return `<div class="hero">
      ${heroRadarSVG()}
      <span class="hero-eyebrow">${escapeHtml(s.heroEyebrow)}</span>
      <h1>${escapeHtml(s.appTitle)}<br>${escapeHtml(s.appSubtitle)}</h1>
      <p class="lead">${escapeHtml(s.heroLead)}</p>
      <div class="hero-actions">
        <button class="btn btn-primary" data-goto="scenarios">Mô phỏng tình huống</button>
	<button class="btn hero-quiz-btn" data-goto="quiz">Ôn tập</button>
      </div>
      <div class="hero-stats">
        <div><div class="hero-stat-num">${DATA.rules.length}</div><div class="hero-stat-label">Điều quy tắc</div></div>
        <div><div class="hero-stat-num">${DATA.scenarios.length}</div><div class="hero-stat-label">Tình huống mô phỏng</div></div>
        <div><div class="hero-stat-num">${DATA.settings.quizRandomCount||20}</div><div class="hero-stat-label">Câu hỏi mỗi lượt ôn tập</div></div>
      </div>
    </div>`;
}
/* =========================================================
   LUẬT THUỶ SẢN — Nội dung
========================================================= */
function fisheriesHeroHTML(){
  return `<div class="hero">
      ${heroRadarSVG()}
      <span class="hero-eyebrow">LUẬT THUỶ SẢN · KHAI THÁC &amp; BẢO VỆ NGUỒN LỢI THUỶ SẢN</span>
      <h1>Luật Thuỷ sản &amp; các quy định<br>về hoạt động khai thác thuỷ sản</h1>
      <p class="lead">Hệ thống hoá Luật Thuỷ sản 2017 cùng các nghị định, thông tư hướng dẫn thi hành liên quan trực tiếp đến hoạt động khai thác thuỷ sản — từ điều kiện cấp phép, quản lý tàu cá đến công tác chống khai thác bất hợp pháp (IUU) — giúp học viên tra cứu nhanh và tự kiểm tra kiến thức.</p>
      <div class="hero-actions">
        <button class="btn hero-quiz-btn" data-goto="fisheries-quiz">Ôn tập</button>
      </div>
      <div class="hero-stats">
        <div><div class="hero-stat-num">${FISHERIES_DOCS.filter(d=>d.group==='Luật').length}</div><div class="hero-stat-label">Văn bản Luật</div></div>
        <div><div class="hero-stat-num">${FISHERIES_DOCS.filter(d=>d.group==='Nghị định').length}</div><div class="hero-stat-label">Nghị định hướng dẫn</div></div>
        <div><div class="hero-stat-num">${FISHERIES_DOCS.filter(d=>d.group==='Thông tư').length}</div><div class="hero-stat-label">Thông tư chuyên ngành</div></div>
      </div>
    </div>`;
}
function fsBadgeTypeClass(group){
  if (group==='Luật') return 'type-luat';
  if (group==='Nghị định') return 'type-nghidinh';
  return 'type-thongtu';
}
function fisheriesDocCardHTML(d){
  const pointsHtml = (d.points&&d.points.length) ? `<ul class="fs-doc-points">${d.points.map(p=>`<li>${escapeHtml(p)}</li>`).join('')}</ul>` : '';
  return `<div class="card fs-doc-card">
    <div class="fs-doc-badges">
      <span class="fs-doc-badge ${fsBadgeTypeClass(d.group)}">${escapeHtml(d.group)}</span>
      <span class="fs-doc-badge tag">${escapeHtml(d.tag)}</span>
    </div>
    <h3>${escapeHtml(d.title)}</h3>
    <div class="fs-doc-meta">
      <span><b>${escapeHtml(d.code)}</b></span>
      <span>${escapeHtml(d.date)}</span>
      <span>Ban hành: ${escapeHtml(d.agency)}</span>
    </div>
    <div class="fs-doc-status">${escapeHtml(d.status)}</div>
    <p class="fs-doc-summary">${escapeHtml(d.summary)}</p>
    ${pointsHtml}
  </div>`;
}
function viewFisheriesContentHTML(){
  const list = currentFsGroup==='Tất cả' ? FISHERIES_DOCS : FISHERIES_DOCS.filter(d=>d.group===currentFsGroup);
  return `<section class="view">
    ${fisheriesHeroHTML()}
    <div class="section-head"><div><span class="section-eyebrow">Luật Thuỷ sản</span><h2>Văn bản pháp luật về khai thác thuỷ sản</h2></div></div>
    <div class="fs-disclaimer">
      <span>ℹ️</span>
      <span><b>Lưu ý:</b> Nội dung dưới đây là danh mục tổng hợp mang tính tham khảo, tóm tắt các văn bản Luật Thuỷ sản và văn bản hướng dẫn thi hành liên quan trực tiếp đến hoạt động khai thác thuỷ sản. Vui lòng đối chiếu văn bản gốc trên Cổng Thông tin điện tử Chính phủ / cơ sở dữ liệu pháp luật quốc gia trước khi áp dụng chính thức, vì các văn bản này có thể tiếp tục được sửa đổi, bổ sung.</span>
    </div>
    <div class="rules-layout">
      <div class="rules-parts">
        ${FS_GROUPS.map(g=>`<button class="fs-group-btn ${g===currentFsGroup?'active':''}" data-fs-group="${escapeAttr(g)}">${escapeHtml(g)}<small>${g==='Tất cả'?FISHERIES_DOCS.length:FISHERIES_DOCS.filter(d=>d.group===g).length}</small></button>`).join('')}
      </div>
      <div>${list.map(fisheriesDocCardHTML).join('')}</div>
    </div>
  </section>`;
}

/* =========================================================
   LUẬT HÀNG HẢI — Giới thiệu & Nội dung
========================================================= */
function maritimeHeroHTML(){
  return `<div class="hero">
      ${heroRadarSVG()}
      <span class="hero-eyebrow">LUẬT HÀNG HẢI · TÀU BIỂN · CẢNG BIỂN · THUYỀN VIÊN</span>
      <h1>Bộ luật Hàng hải Việt Nam<br>&amp; các văn bản hướng dẫn thi hành</h1>
      <p class="lead">Hệ thống hoá Bộ luật Hàng hải Việt Nam 2015 cùng các nghị định, thông tư hướng dẫn thi hành — từ đăng ký tàu biển, quản lý cảng biển đến tiêu chuẩn thuyền viên và xử phạt vi phạm hành chính — giúp học viên tra cứu nhanh và tự kiểm tra kiến thức.</p>
      <div class="hero-actions">
        <button class="btn hero-quiz-btn" data-goto="maritime-quiz">Ôn tập</button>
      </div>
      <div class="hero-stats">
        <div><div class="hero-stat-num">${MARITIME_DOCS.filter(d=>d.group==='Luật').length}</div><div class="hero-stat-label">Văn bản Luật</div></div>
        <div><div class="hero-stat-num">${MARITIME_DOCS.filter(d=>d.group==='Nghị định').length}</div><div class="hero-stat-label">Nghị định hướng dẫn</div></div>
        <div><div class="hero-stat-num">${MARITIME_DOCS.filter(d=>d.group==='Thông tư').length}</div><div class="hero-stat-label">Thông tư chuyên ngành</div></div>
      </div>
    </div>`;
}
function viewMaritimeContentHTML(){
  const list = currentMtGroup==='Tất cả' ? MARITIME_DOCS : MARITIME_DOCS.filter(d=>d.group===currentMtGroup);
  return `<section class="view">
    ${maritimeHeroHTML()}
    <div class="section-head"><div><span class="section-eyebrow">Luật Hàng hải</span><h2>Văn bản pháp luật về hoạt động hàng hải</h2></div></div>
    <div class="fs-disclaimer">
      <span>ℹ️</span>
      <span><b>Lưu ý:</b> Nội dung dưới đây là danh mục tổng hợp mang tính tham khảo, tóm tắt các văn bản Bộ luật Hàng hải Việt Nam và văn bản hướng dẫn thi hành liên quan đến tàu biển, cảng biển, thuyền viên. Vui lòng đối chiếu văn bản gốc trên Cổng Thông tin điện tử Chính phủ / cơ sở dữ liệu pháp luật quốc gia trước khi áp dụng chính thức, vì các văn bản này có thể tiếp tục được sửa đổi, bổ sung.</span>
    </div>
    <div class="rules-layout">
      <div class="rules-parts">
        ${MT_GROUPS.map(g=>`<button class="fs-group-btn ${g===currentMtGroup?'active':''}" data-mt-group="${escapeAttr(g)}">${escapeHtml(g)}<small>${g==='Tất cả'?MARITIME_DOCS.length:MARITIME_DOCS.filter(d=>d.group===g).length}</small></button>`).join('')}
      </div>
      <div>${list.map(fisheriesDocCardHTML).join('')}</div>
    </div>
  </section>`;
}
function viewQuizTakeHTML(){
  const manageBtn = isLoggedIn?`<button class="btn btn-ghost btn-sm" data-toggle-quiz-manage>${iconSpan('edit')} Quản lý câu hỏi</button>`:'';
  const header = `<div class="section-head"><div><span class="section-eyebrow">Tự kiểm tra</span><h2>Câu hỏi ôn tập</h2></div>${manageBtn}</div>`;
  if (!quizTaker) return `<section class="view">${header}${quizTakerFormInnerHTML()}</section>`;
  if (quizLoadingQuestions) return `<section class="view">${header}${quizLoadingInnerHTML()}</section>`;
  if (!quizSessionQuestions || quizSessionQuestions.length===0) return `<section class="view">${header}<div class="empty-note">Không có câu hỏi khả dụng. Kiểm tra lại đường liên kết Google Sheet hoặc ngân hàng câu hỏi cục bộ.</div></section>`;
  let inner;
  if (quizFinished) inner = quizResultInnerHTML();
  else inner = quizActiveInnerHTML();
  return `<section class="view">${header}${inner}</section>`;
}
function clearQuizTimer(){
  if (quizTimerInterval){ clearInterval(quizTimerInterval); quizTimerInterval = null; }
}
function updateQuizTimerDisplay(){
  const el = document.getElementById('quiz-timer-display');
  if (!el || !quizDeadline) return;
  const remain = Math.max(0, quizDeadline - Date.now());
  const mm = Math.floor(remain/60000);
  const ss = Math.floor((remain%60000)/1000);
  el.textContent = `${String(mm).padStart(2,'0')}:${String(ss).padStart(2,'0')}`;
  el.classList.toggle('quiz-timer-warning', remain <= 60000);
}
function startQuizTimer(){
  clearQuizTimer();
  const durMin = (DATA.settings.examDurationMinutes && DATA.settings.examDurationMinutes > 0) ? DATA.settings.examDurationMinutes : 10;
  quizDeadline = Date.now() + durMin*60*1000;
  updateQuizTimerDisplay();
  quizTimerInterval = setInterval(()=>{
    const remain = quizDeadline - Date.now();
    if (remain <= 0){
      clearQuizTimer();
      if (!quizFinished && quizTaker){
        quizFinished = true;
        quizAutoSubmitted = true;
        submitQuizResult();
        clearQuizSessionStorage();
        if (currentView==='quiz' || currentView==='fisheries-quiz' || currentView==='maritime-quiz') renderView();
      }
      return;
    }
    updateQuizTimerDisplay();
  }, 1000);
}
async function startQuizWithTakerInfo(){
  const nameEl = document.getElementById('taker-name');
  const yearEl = document.getElementById('taker-birthyear');
  const errEl = document.getElementById('taker-form-error');
  const name = nameEl.value.trim();
  const yearStr = yearEl.value.trim();
  const year = parseInt(yearStr,10);
  const nowYear = new Date().getFullYear();
  if (!name){ errEl.textContent = 'Vui lòng nhập họ và tên.'; return; }
  if (!yearStr || isNaN(year) || year < 1940 || year > nowYear){ errEl.textContent = 'Vui lòng nhập năm sinh hợp lệ.'; return; }
  quizTaker = { name, birthYear: year };

  quizLoadingQuestions = true;
  renderView();

  quizSessionQuestions = await loadQuizQuestionsForSession();

  quizLoadingQuestions = false;
  quizIndex=0; quizScore=0; quizSelected=null; quizFinished=false; quizAutoSubmitted=false;
  startQuizTimer();
  saveQuizSessionToStorage();
  renderView();
}
async function submitQuizResult(){
  if (!quizTaker) return;
  const total = quizSessionQuestions ? quizSessionQuestions.length : 0;
  const record = {
    name: quizTaker.name,
    birthYear: quizTaker.birthYear,
    score: quizScore,
    total,
    percent: total? Math.round((quizScore/total)*100) : 0,
    submittedAt: new Date().toISOString()
  };
  // 1) luôn lưu bản sao trong ứng dụng để quản trị viên xem được dù chưa cấu hình Google Sheet
  try{ await appendQuizResult(record); }catch(e){ /* bỏ qua */ }
  // 2) nếu đã cấu hình, cố gắng gửi thêm sang Google Apps Script Web App (best-effort)
  const url = DATA.settings.resultsWebhookUrl;
  if (url){
    try{
      await fetch(url, {
        method: 'POST',
        mode: 'no-cors',
        headers: {'Content-Type':'text/plain;charset=utf-8'},
        body: JSON.stringify(record)
      });
    }catch(e){ /* lỗi mạng/CORS khi dùng no-cors là bình thường, bỏ qua */ }
  }
}
function quizResultInnerHTML(){
  const total = quizSessionQuestions ? quizSessionQuestions.length : 0;
  const pct = total? Math.round((quizScore/total)*100) : 0;
  const msg = pct>=80?'Xuất sắc! Bạn nắm rất vững quy tắc.':pct>=50?'Khá tốt — nên ôn lại một số điều còn nhầm lẫn.':'Nên xem lại phần Quy tắc và làm lại bài ôn tập.';
  return `<div class="card quiz-card">
      <div class="quiz-result">
        <div class="quiz-progress">Kết quả${quizTaker?` — ${escapeHtml(quizTaker.name)}`:''}</div>
        <div class="score-num">${quizScore}/${total}</div>
        <p>${msg}</p>
        ${quizAutoSubmitted?`<p style="font-size:12.5px;color:var(--giveway);font-weight:700;">⏱ Đã hết thời gian làm bài — bài của bạn được tự động nộp.</p>`:''}
        <p style="font-size:12.5px;color:var(--ink-soft);">Kết quả của bạn đã được ghi nhận.</p>
        <button class="btn btn-primary" data-quiz-restart>Làm lại từ đầu</button>
      </div>
    </div>`;
}
function quizEditFormHTML(q){
  return `<div class="edit-card">
    <h4>${iconSpan('edit')} Chỉnh sửa câu hỏi</h4>
    <div class="form-field"><label>Nội dung câu hỏi</label><textarea id="qf-${q.id}-prompt">${escapeHtml(q.prompt)}</textarea></div>
    ${q.options.map((opt,i)=>`<div class="form-field"><label>Đáp án ${String.fromCharCode(65+i)}</label><input type="text" id="qf-${q.id}-opt-${i}" value="${escapeAttr(opt)}"></div>`).join('')}
    <div class="form-field"><label>Đáp án đúng</label>
      <select id="qf-${q.id}-correct">${q.options.map((opt,i)=>`<option value="${i}" ${q.correct===i?'selected':''}>${String.fromCharCode(65+i)}</option>`).join('')}</select>
    </div>
    <div class="form-field"><label>Giải thích</label><textarea id="qf-${q.id}-explain">${escapeHtml(q.explain)}</textarea></div>
    <div class="edit-actions">
      <button class="btn btn-primary btn-sm" data-save-quiz="${q.id}">Lưu</button>
      <button class="btn btn-ghost btn-sm" data-cancel-quiz>Huỷ</button>
      <button class="btn btn-danger btn-sm" data-delete-quiz="${q.id}" style="margin-left:auto;">${iconSpan('trash')} Xoá câu hỏi</button>
    </div>
  </div>`;
}
function quizManageItemHTML(q,idx){
  const editing = editingQuizId===q.id;
  return `<div class="card rule-item">
    <span class="rule-num">Câu ${idx+1}</span>
    <button class="btn btn-ghost btn-sm" style="float:right" data-edit-quiz="${q.id}">${iconSpan('edit')} ${editing?'Đóng':'Sửa'}</button>
    <h3>${escapeHtml(q.prompt)}</h3>
    <div class="rule-body">Đáp án đúng: ${escapeHtml(q.options[q.correct]||'')}</div>
    ${editing?quizEditFormHTML(q):''}
  </div>`;
}
function quizWebhookPanelHTML(){
  if (!webhookPanelOpen) return "";
  const url = DATA.settings.resultsWebhookUrl || "";
  const durMin = DATA.settings.examDurationMinutes || 10;
  const sheetUrl = DATA.settings.quizSheetUrl || "";
  const randomCount = DATA.settings.quizRandomCount || 20;
  return `<div class="edit-card" style="margin-bottom:20px;">
    <h4>${iconSpan('edit')} Cài đặt bài ôn tập — nguồn câu hỏi, thời gian &amp; nhận kết quả</h4>

    <p style="font-size:13px;">Câu hỏi được lấy trực tiếp từ Google Sheet này mỗi khi có người bắt đầu làm bài — sửa nội dung trong Sheet là web tự cập nhật theo, không cần làm gì thêm ở đây. Sheet cần chia sẻ ở chế độ "Bất kỳ ai có đường liên kết – Người xem". Nếu để trống hoặc tải lỗi, hệ thống sẽ dùng tạm ngân hàng câu hỏi cục bộ (mục "Quản lý câu hỏi" bên dưới).</p>
    <div class="form-field"><label>URL Google Sheet chứa câu hỏi</label><input type="text" id="set-quizSheetUrl" placeholder="https://docs.google.com/spreadsheets/d/..." value="${escapeAttr(sheetUrl)}"></div>
    <p style="font-size:12.5px;color:var(--ink-soft);margin-top:-6px;">⚠️ Một số trình duyệt có thể chặn cách tải trực tiếp ở trên do chính sách CORS của Google. Nếu bài ôn tập báo lỗi và dùng tạm ngân hàng cục bộ dù Sheet vẫn đúng, hãy cấu hình thêm URL Apps Script trung chuyển bên dưới (đáng tin cậy hơn, không bao giờ bị chặn) — xem hướng dẫn kèm theo.</p>
    <div class="form-field"><label>URL Apps Script trung chuyển đọc câu hỏi (không bắt buộc, dự phòng)</label><input type="text" id="set-quizSheetProxyUrl" placeholder="https://script.google.com/macros/s/xxx/exec" value="${escapeAttr(DATA.settings.quizSheetProxyUrl||'')}"></div>
    <div class="form-field">
      <label>Số câu hỏi ngẫu nhiên mỗi lượt làm bài</label>
      <input type="number" id="set-quizRandomCount" min="1" max="200" value="${randomCount}">
    </div>

    <div class="form-field" style="margin-top:16px;">
      <label>Thời gian làm bài (phút)</label>
      <input type="number" id="set-examDuration" min="1" max="180" value="${durMin}">
    </div>
    <p style="font-size:12.5px;color:var(--ink-soft);margin-top:-6px;">Hết thời gian này, bài đang làm sẽ tự động được nộp.</p>
    <p style="font-size:13px;margin-top:14px;">Dán vào đây URL "Web App" của Google Apps Script đã triển khai trên Google Sheet của bạn. Mỗi khi có người nộp bài, kết quả (họ tên, năm sinh, điểm) sẽ được gửi tới đó — dùng chung một liên kết cho mọi thiết bị. Dù có cấu hình hay không, kết quả luôn được lưu lại trong mục "Xem kết quả đã nộp" bên dưới.</p>
    <div class="form-field"><label>URL Web App (Google Apps Script)</label><input type="text" id="set-webhookUrl" placeholder="https://script.google.com/macros/s/xxx/exec" value="${escapeAttr(url)}"></div>
    <div class="edit-actions">
      <button class="btn btn-primary btn-sm" data-save-webhook>Lưu cài đặt</button>
      <button class="btn btn-ghost btn-sm" data-toggle-webhook-panel>Đóng</button>
    </div>
  </div>`;
}

function quizImportPanelHTML(){
  if (!importPanelOpen) return "";
  return `<div class="edit-card" style="margin-bottom:20px;">
    <h4>${iconSpan('plus')} Nhập câu hỏi hàng loạt (Excel / Google Sheet)</h4>
    <p style="font-size:13px;">Chuẩn bị bảng tính theo đúng 7 cột theo thứ tự: <b>Câu hỏi, Đáp án A, Đáp án B, Đáp án C, Đáp án D, Đáp án đúng (A/B/C/D), Giải thích</b>. Dòng tiêu đề (nếu có) sẽ tự động được bỏ qua.</p>
    <div class="form-row-2">
      <div class="form-field"><label>Tải lên file Excel (.xlsx)</label><input type="file" id="quiz-import-file" accept=".xlsx,.xls"></div>
      <div class="form-field"><label>...hoặc dán link Google Sheet (đã chia sẻ "Người xem")</label><input type="text" id="quiz-import-sheet-url" placeholder="https://docs.google.com/spreadsheets/d/..." value="${escapeAttr(quizImportSheetUrlDraft)}"></div>
    </div>
    <div class="edit-actions">
      <button class="btn btn-ghost btn-sm" data-download-template>Tải file mẫu (.xlsx)</button>
      <button class="btn btn-primary btn-sm" data-import-file>Xử lý file đã chọn</button>
      <button class="btn btn-primary btn-sm" data-import-sheet>Nhập từ Google Sheet</button>
      <button class="btn btn-ghost btn-sm" data-toggle-import-panel>Đóng</button>
    </div>
    ${importStatusMessage ? `<div class="quiz-explain" style="margin-top:10px;">${escapeHtml(importStatusMessage)}</div>` : ''}
    ${pendingImportErrors.length ? `<div class="quiz-explain" style="margin-top:8px;border-left:3px solid var(--giveway);">${pendingImportErrors.map(e=>escapeHtml(e)).join('<br>')}</div>` : ''}
    ${pendingImportDrafts.length ? `
      <div style="margin-top:14px;">
        <strong>Xem trước ${pendingImportDrafts.length} câu hỏi sẽ được thêm:</strong>
        <ol style="font-size:13.5px;padding-left:20px;">
          ${pendingImportDrafts.map(d=>`<li>${escapeHtml(d.prompt)} <em>(đúng: ${escapeHtml(d.options[d.correct])})</em></li>`).join('')}
        </ol>
        <div class="edit-actions">
          <button class="btn btn-primary btn-sm" data-commit-import>Xác nhận thêm ${pendingImportDrafts.length} câu hỏi</button>
          <button class="btn btn-ghost btn-sm" data-cancel-import>Huỷ bỏ</button>
        </div>
      </div>` : ''}
  </div>`;
}

function quizResultsPanelHTML(){
  if (!resultsViewOpen) return "";
  return `<div class="edit-card" style="margin-bottom:20px;">
    <h4>${iconSpan('check')} Kết quả đã nộp (${QUIZ_RESULTS.length})</h4>
    ${QUIZ_RESULTS.length ? `
    <div style="overflow-x:auto;">
    <table style="width:100%;border-collapse:collapse;font-size:13px;">
      <thead><tr style="text-align:left;border-bottom:2px solid var(--line);">
        <th style="padding:6px;">#</th><th style="padding:6px;">Họ và tên</th><th style="padding:6px;">Năm sinh</th><th style="padding:6px;">Điểm</th><th style="padding:6px;">Tỉ lệ</th><th style="padding:6px;">Thời điểm nộp</th>
      </tr></thead>
      <tbody>
        ${QUIZ_RESULTS.slice().reverse().map((r,i)=>`<tr style="border-bottom:1px solid var(--line-soft);">
          <td style="padding:6px;">${QUIZ_RESULTS.length-i}</td>
          <td style="padding:6px;">${escapeHtml(r.name)}</td>
          <td style="padding:6px;">${escapeHtml(String(r.birthYear))}</td>
          <td style="padding:6px;">${r.score}/${r.total}</td>
          <td style="padding:6px;">${r.percent}%</td>
          <td style="padding:6px;">${escapeHtml(new Date(r.submittedAt).toLocaleString('vi-VN'))}</td>
        </tr>`).join('')}
      </tbody>
    </table>
    </div>` : `<p style="font-size:13px;">Chưa có ai nộp bài.</p>`}
    <div class="edit-actions">
      <button class="btn btn-ghost btn-sm" data-refresh-results>Làm mới</button>
      ${QUIZ_RESULTS.length? `<button class="btn btn-ghost btn-sm" data-export-results-csv>Xuất CSV</button>`:''}
      <button class="btn btn-ghost btn-sm" data-toggle-results-view>Đóng</button>
      ${QUIZ_RESULTS.length? `<button class="btn btn-danger btn-sm" data-clear-results style="margin-left:auto;">${iconSpan('trash')} Xoá toàn bộ kết quả</button>`:''}
    </div>
  </div>`;
}

function viewQuizManageHTML(){
  return `<section class="view">
    <div class="section-head">
      <div><span class="section-eyebrow">Quản trị</span><h2>Quản lý câu hỏi ôn tập</h2></div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;">
        <button class="btn btn-ghost btn-sm" data-toggle-webhook-panel>Cài đặt bài ôn tập</button>
        <button class="btn btn-ghost btn-sm" data-toggle-import-panel>Nhập hàng loạt</button>
        <button class="btn btn-ghost btn-sm" data-toggle-results-view>Xem kết quả đã nộp</button>
        <button class="btn btn-brass btn-sm" data-add-quiz>${iconSpan('plus')} Thêm câu hỏi</button>
        <button class="btn btn-ghost btn-sm" data-toggle-quiz-manage>${iconSpan('x')} Đóng quản lý</button>
      </div>
    </div>
    ${quizWebhookPanelHTML()}
    ${quizImportPanelHTML()}
    ${quizResultsPanelHTML()}
    ${DATA.quiz.map((q,idx)=>quizManageItemHTML(q,idx)).join('') || `<div class="empty-note">Chưa có câu hỏi nào. Hãy thêm câu hỏi mới.</div>`}
  </section>`;
}
function viewQuizHTML(){
  return (quizManageMode && isLoggedIn) ? viewQuizManageHTML() : viewQuizTakeHTML();
}

/* =========================================================
   ĐIỀU HƯỚNG / RENDER GỐC
========================================================= */
const NAV_GROUPS = {
  colreg: ['rules','scenarios','quiz'],
  fisheries: ['fisheries-content','fisheries-quiz'],
  maritime: ['maritime-content','maritime-quiz']
};
function setActiveNav(){
  document.querySelectorAll('.nav-btn[data-view]').forEach(b=>b.classList.toggle('active', b.dataset.view===currentView));
  document.querySelectorAll('.nav-dropdown-item').forEach(b=>b.classList.toggle('active', b.dataset.view===currentView));
  document.querySelectorAll('[data-nav-toggle]').forEach(btn=>{
    const group = NAV_GROUPS[btn.dataset.navToggle] || [];
    btn.classList.toggle('active', group.includes(currentView));
  });
}
function renderBrand(){
  document.getElementById('brand-emblem').innerHTML = buildEmblemMarkup();
  document.getElementById('org-name-display').textContent = DATA.settings.orgName;
  document.querySelector('.brand-app').textContent = DATA.settings.appTitle;
  document.getElementById('footer-text').textContent = DATA.settings.footerText;
  const faviconUrl = (DATA.settings.logoImageUrl||'').trim();
  if (faviconUrl){
    let iconLink = document.querySelector('link[rel="icon"]');
    if (!iconLink){ iconLink = document.createElement('link'); iconLink.rel = 'icon'; document.head.appendChild(iconLink); }
    iconLink.type = 'image/png';
    iconLink.href = faviconUrl;
  }
}
function renderView(){
  const root = document.getElementById('view-root');
  clearInterval(bannerCarouselInterval); bannerCarouselInterval = null;
  if (currentView==='home') root.innerHTML = viewHomeHTML();
  else if (currentView==='rules') root.innerHTML = viewRulesHTML();
  else if (currentView==='scenarios') root.innerHTML = currentScenarioId ? viewScenarioDetailHTML(currentScenarioId) : viewScenariosListHTML();
  else if (currentView==='quiz') root.innerHTML = viewQuizHTML();
  else if (currentView==='fisheries-content') root.innerHTML = viewFisheriesContentHTML();
  else if (currentView==='fisheries-quiz') root.innerHTML = viewQuizHTML();
  else if (currentView==='maritime-content') root.innerHTML = viewMaritimeContentHTML();
  else if (currentView==='maritime-quiz') root.innerHTML = viewQuizHTML();
  updateQuizTimerDisplay();
  if (currentView==='home') startBannerCarousel();
}
function switchView(view){
  currentView = view;
  currentScenarioId = null;
  settingsEditOpen = false;
  scenarioEditOpen = false;
  editingRuleId = null;
  setActiveNav();
  renderView();
  window.scrollTo({top:0,behavior:'smooth'});
}

/* =========================================================
   ĐĂNG NHẬP / ĐĂNG XUẤT
========================================================= */
function updateAuthUI(){
  const statusEl = document.getElementById('login-status');
  statusEl.textContent = isLoggedIn ? `Chế độ chỉnh sửa (${AUTH_USER})` : 'Chế độ Khách';
  statusEl.classList.toggle('on', isLoggedIn);
  document.getElementById('login-toggle-btn').textContent = isLoggedIn ? 'Đăng xuất' : 'Đăng nhập';
}
function openLoginModal(){
  document.getElementById('login-modal').classList.remove('hidden');
  document.getElementById('login-user').value = '';
  document.getElementById('login-pass').value = '';
  document.getElementById('login-error').textContent = '';
  setTimeout(()=>document.getElementById('login-user').focus(), 30);
}
function closeLoginModal(){ document.getElementById('login-modal').classList.add('hidden'); }
function attemptLogin(){
  const u = document.getElementById('login-user').value.trim();
  const p = document.getElementById('login-pass').value;
  if (u===AUTH_USER && p===AUTH_PASS){
    isLoggedIn = true;
    closeLoginModal();
    updateAuthUI();
    renderView();
    showToast('Đăng nhập thành công — chế độ chỉnh sửa đã bật.');
  } else {
    document.getElementById('login-error').textContent = 'Sai tài khoản hoặc mật khẩu.';
  }
}
function doLogout(){
  isLoggedIn = false;
  settingsEditOpen=false; scenarioEditOpen=false; editingRuleId=null; quizManageMode=false; editingQuizId=null;
  updateAuthUI();
  renderView();
  showToast('Đã đăng xuất khỏi chế độ chỉnh sửa.');
}

/* =========================================================
   HÀNH ĐỘNG: CÀI ĐẶT / GIAO DIỆN
========================================================= */
function saveSettingsFromForm(){
  const s = DATA.settings;
  s.appTitle = document.getElementById('set-appTitle').value.trim() || s.appTitle;
  s.appSubtitle = document.getElementById('set-appSubtitle').value.trim() || s.appSubtitle;
  s.orgName = document.getElementById('set-orgName').value.trim() || s.orgName;
  s.heroEyebrow = document.getElementById('set-heroEyebrow').value.trim() || s.heroEyebrow;
  s.heroLead = document.getElementById('set-heroLead').value.trim() || s.heroLead;
  s.footerText = document.getElementById('set-footerText').value.trim() || s.footerText;
  s.emblem = document.getElementById('set-emblem').value;
  s.logoImageUrl = document.getElementById('set-logoUrl').value.trim();
  const bannerContainer = document.getElementById('banner-images-list');
  if (bannerContainer){
    const urlInputs = Array.from(bannerContainer.querySelectorAll('.banner-img-url-input'));
    const capInputs = Array.from(bannerContainer.querySelectorAll('.banner-img-caption-input'));
    s.bannerImages = urlInputs.map((inp,i)=>({url:inp.value.trim(), caption: capInputs[i]?capInputs[i].value.trim():''})).filter(x=>x.url.length>0);
  }
  settingsEditOpen = false;
  persistAppData();
  renderBrand();
  renderView();
  window.scrollTo({top:0, behavior:'instant'});
  showToast('Đã lưu thay đổi giao diện.');
}
function resetToDefaults(){
  const ok = confirm('Thao tác này sẽ XOÁ mọi chỉnh sửa hiện có (quy tắc, tình huống, câu hỏi, giao diện) và khôi phục về đúng nội dung mặc định đang có trong mã nguồn (DEFAULT_RULES / DEFAULT_SCENARIOS / DEFAULT_QUIZ / DEFAULT_SETTINGS). Không thể hoàn tác. Bạn có chắc chắn muốn tiếp tục?');
  if (!ok) return;
  DATA = {
    rules: deepClone(DEFAULT_RULES),
    scenarios: normalizeScenarios(deepClone(DEFAULT_SCENARIOS)),
    quiz: deepClone(DEFAULT_QUIZ),
    settings: deepClone(DEFAULT_SETTINGS)
  };
  settingsEditOpen = false; scenarioEditOpen = false; editingRuleId = null; editingQuizId = null; quizManageMode = false;
  clearQuizTimer(); quizDeadline = null; quizAutoSubmitted = false; quizTaker = null;
  quizIndex = 0; quizScore = 0; quizSelected = null; quizFinished = false;
  currentView = 'home'; currentScenarioId = null; currentPart = 'A';
  persistAppData();
  renderBrand();
  setActiveNav();
  renderView();
  window.scrollTo({top:0, behavior:'instant'});
  showToast('Đã khôi phục toàn bộ dữ liệu về mặc định trong mã nguồn.');
}

/* =========================================================
   HÀNH ĐỘNG: QUY TẮC
========================================================= */
function saveRuleFromForm(id){
  const r = DATA.rules.find(x=>x.id===id); if (!r) return;
  r.num = document.getElementById(`rf-${id}-num`).value.trim() || r.num;
  r.title = document.getElementById(`rf-${id}-title`).value.trim() || r.title;
  r.body = document.getElementById(`rf-${id}-body`).value.trim() || r.body;
  editingRuleId = null;
  persistAppData();
  renderView();
  showToast('Đã lưu điều luật.');
}

/* =========================================================
   HÀNH ĐỘNG: TÌNH HUỐNG MÔ PHỎNG
========================================================= */
function saveScenarioFromForm(id){
  const sc = DATA.scenarios.find(s=>s.id===id); if (!sc) return;
  const g = suffix => document.getElementById(`ef-${id}-${suffix}`);
  sc.title = g('title').value.trim() || sc.title;
  sc.ruleRef = g('ruleRef').value.trim() || sc.ruleRef;
  sc.summary = g('summary').value.trim() || sc.summary;
  sc.description = g('description').value.trim() || sc.description;
  sc.action = g('action').value.trim() || sc.action;
  sc.soundSignals = (function(){
    const container = document.getElementById(`signals-list-${id}`);
    if (!container) return sc.soundSignals || [];
    const textInputs = Array.from(container.querySelectorAll('.signal-input'));
    const audioInputs = Array.from(container.querySelectorAll('.signal-audio-input'));
    const result = [];
    textInputs.forEach((inp, i)=>{
      const text = inp.value.trim();
      if (!text) return;
      const audioUrl = audioInputs[i] ? audioInputs[i].value.trim() : '';
      result.push({ text, audioUrl });
    });
    return result;
  })();
  ['ownShip','targetShip'].forEach(key=>{
    const v = sc[key];
    const gv = suffix => document.getElementById(`ef-${id}-${key}-${suffix}`);
    v.name = gv('name').value.trim() || v.name;
    v.type = gv('type').value;
    v.role = gv('role').value;
    v.heading = norm360(parseFloat(gv('heading').value), v.heading);
    v.x = clampNum(parseFloat(gv('x').value), 20, 400, v.x);
    v.y = clampNum(parseFloat(gv('y').value), 20, 400, v.y);
    v.imageUrl = gv('img').value.trim();
  });
  sc.environment.currentDir = norm360(parseFloat(g('currentDir').value), sc.environment.currentDir);
  sc.environment.currentSpeed = Math.max(0, parseFloat(g('currentSpeed').value)||0);
  sc.environment.windDir = norm360(parseFloat(g('windDir').value), sc.environment.windDir);
  sc.environment.windSpeed = Math.max(0, parseFloat(g('windSpeed').value)||0);
  sc.environment.visibility = g('visibility').value.trim() || sc.environment.visibility;
  sc.environment.showCurrent = g('showCurrent').value === '1';
  sc.environment.showWind = g('showWind').value === '1';
  scenarioEditOpen = false;
  persistAppData();
  renderView();
  showToast('Đã lưu tình huống mô phỏng.');
}
function deleteScenarioById(id){
  if (!confirm('Xoá tình huống này? Hành động không thể hoàn tác.')) return;
  DATA.scenarios = DATA.scenarios.filter(s=>s.id!==id);
  scenarioEditOpen = false; currentScenarioId = null; currentView = 'scenarios';
  persistAppData();
  renderView();
  showToast('Đã xoá tình huống.');
}
function addNewScenario(){
  const id = 'sc-'+Date.now();
  const newSc = {
    id, title:"Tình huống mới", ruleRef:"Điều ...", roleTag:"neutral",
    summary:"Mô tả ngắn gọn hiển thị ở danh sách.",
    description:"Nhập mô tả diễn biến tình huống ở đây.",
    action:"Nhập hành động cần thực hiện.",
    soundSignals: [{text:"Nhập tín hiệu còi (nếu có).", audioUrl:""}],
    showTurnArrows:false,
    ownShip:{name:"Tàu ta",type:"power",x:210,y:300,heading:0,role:"neutral"},
    targetShip:{name:"Tàu mục tiêu",type:"power",x:210,y:130,heading:180,role:"neutral"},
    environment:{currentDir:0,currentSpeed:0,windDir:0,windSpeed:0,visibility:"Tốt",showCurrent:true,showWind:false}
  };
  DATA.scenarios.push(newSc);
  currentView='scenarios'; currentScenarioId=id; scenarioEditOpen=true;
  persistAppData();
  renderView();
  showToast('Đã thêm tình huống mới — hãy điền chi tiết bên dưới.');
}

/* =========================================================
   HÀNH ĐỘNG: CÂU HỎI ÔN TẬP
========================================================= */
function saveQuizFromForm(id){
  const q = DATA.quiz.find(x=>x.id===id); if (!q) return;
  q.prompt = document.getElementById(`qf-${id}-prompt`).value.trim() || q.prompt;
  q.options = q.options.map((opt,i)=>{
    const el = document.getElementById(`qf-${id}-opt-${i}`);
    return (el && el.value.trim()) || opt;
  });
  q.correct = parseInt(document.getElementById(`qf-${id}-correct`).value,10) || 0;
  q.explain = document.getElementById(`qf-${id}-explain`).value.trim() || q.explain;
  editingQuizId = null;
  persistAppData();
  renderView();
  showToast('Đã lưu câu hỏi.');
}
function deleteQuizById(id){
  if (!confirm('Xoá câu hỏi này?')) return;
  DATA.quiz = DATA.quiz.filter(q=>q.id!==id);
  editingQuizId = null;
  if (quizIndex>=DATA.quiz.length) quizIndex = Math.max(0, DATA.quiz.length-1);
  persistAppData();
  renderView();
  showToast('Đã xoá câu hỏi.');
}
function addNewQuiz(){
  const id = 'q-'+Date.now();
  DATA.quiz.push({id,prompt:"Nhập nội dung câu hỏi mới...",options:["Đáp án A","Đáp án B","Đáp án C","Đáp án D"],correct:0,explain:"Nhập giải thích cho đáp án đúng."});
  editingQuizId = id;
  persistAppData();
  renderView();
  showToast('Đã thêm câu hỏi mới — hãy điền nội dung.');
}

/* =========================================================
   HÀNH ĐỘNG: CÀI ĐẶT NHẬN KẾT QUẢ (Google Apps Script Webhook)
========================================================= */
function saveWebhookUrl(){
  DATA.settings.resultsWebhookUrl = document.getElementById('set-webhookUrl').value.trim();
  DATA.settings.quizSheetUrl = document.getElementById('set-quizSheetUrl').value.trim();
  DATA.settings.quizSheetProxyUrl = document.getElementById('set-quizSheetProxyUrl').value.trim();
  const countInput = document.getElementById('set-quizRandomCount');
  const count = parseInt(countInput.value, 10);
  DATA.settings.quizRandomCount = (!isNaN(count) && count > 0) ? count : (DATA.settings.quizRandomCount || 20);
  const durInput = document.getElementById('set-examDuration');
  const dur = parseInt(durInput.value, 10);
  DATA.settings.examDurationMinutes = (!isNaN(dur) && dur > 0) ? dur : (DATA.settings.examDurationMinutes || 10);
  persistAppData();
  showToast('Đã lưu cài đặt bài ôn tập.');
}

/* =========================================================
   HÀNH ĐỘNG: NHẬP CÂU HỎI HÀNG LOẠT
========================================================= */
async function downloadQuizTemplate(){
  importStatusMessage = 'Đang chuẩn bị file mẫu...';
  renderView();
  try{
    await ensureXLSX();
    const aoa = [
      ["Câu hỏi","Đáp án A","Đáp án B","Đáp án C","Đáp án D","Đáp án đúng (A/B/C/D)","Giải thích"],
      ["Ví dụ: Tín hiệu 1 tiếng còi ngắn có nghĩa là gì?","Chuyển hướng sang trái","Chuyển hướng sang phải","Máy đang chạy lùi","Xin vượt","B","Theo Điều 34, 1 tiếng ngắn nghĩa là chuyển hướng sang phải."]
    ];
    const ws = XLSX.utils.aoa_to_sheet(aoa);
    ws['!cols'] = [{wch:42},{wch:22},{wch:22},{wch:22},{wch:22},{wch:20},{wch:42}];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "CauHoi");
    XLSX.writeFile(wb, "mau-cau-hoi-on-tap.xlsx");
    importStatusMessage = 'Đã tải file mẫu. Điền câu hỏi theo đúng cột rồi tải lên lại ở trên.';
  }catch(e){
    importStatusMessage = 'Không tải được thư viện Excel để tạo file mẫu: ' + e.message;
  }
  renderView();
}

function processImportedRows(rows){
  const { drafts, errors } = rowsToQuizDrafts(rows);
  pendingImportDrafts = drafts;
  pendingImportErrors = errors;
  importStatusMessage = drafts.length
    ? `Đã đọc được ${drafts.length} câu hỏi hợp lệ.` + (errors.length ? ` (${errors.length} dòng bị bỏ qua do lỗi, xem bên dưới)` : '')
    : 'Không tìm thấy câu hỏi hợp lệ nào trong dữ liệu. Kiểm tra lại định dạng theo file mẫu.';
}

async function handleExcelFileImport(){
  const fileInput = document.getElementById('quiz-import-file');
  const file = fileInput && fileInput.files && fileInput.files[0];
  if (!file){ importStatusMessage = 'Vui lòng chọn một file Excel trước.'; renderView(); return; }
  importStatusMessage = 'Đang tải thư viện đọc Excel...';
  pendingImportDrafts = []; pendingImportErrors = [];
  renderView();
  try{
    await ensureXLSX();
    importStatusMessage = 'Đang đọc file...';
    renderView();
    const data = await file.arrayBuffer();
    const wb = XLSX.read(data, {type:'array'});
    const sheet = wb.Sheets[wb.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json(sheet, {header:1, raw:false, defval:""});
    processImportedRows(rows);
  }catch(e){
    importStatusMessage = 'Lỗi khi đọc file: ' + e.message;
  }
  renderView();
}

async function handleSheetImport(){
  const urlInput = document.getElementById('quiz-import-sheet-url');
  const url = urlInput.value.trim();
  quizImportSheetUrlDraft = url;
  if (!url){ importStatusMessage = 'Vui lòng dán link Google Sheet.'; renderView(); return; }
  const { id, gid } = extractSheetIdAndGid(url);
  if (!id){ importStatusMessage = 'Không nhận diện được ID của Google Sheet từ link này.'; renderView(); return; }
  importStatusMessage = 'Đang tải dữ liệu từ Google Sheet...';
  pendingImportDrafts = []; pendingImportErrors = [];
  renderView();
  try{
    const csvUrl = buildSheetCsvUrl(id, gid);
    const resp = await fetch(csvUrl);
    if (!resp.ok) throw new Error('Không truy cập được (HTTP '+resp.status+'). Hãy chắc chắn Sheet đã chia sẻ ở chế độ "Bất kỳ ai có đường liên kết – Người xem".');
    const text = await resp.text();
    const rows = parseCSV(text);
    processImportedRows(rows);
  }catch(e){
    importStatusMessage = 'Lỗi khi nhập từ Google Sheet: ' + e.message;
  }
  renderView();
}

function commitImportedQuiz(){
  if (!pendingImportDrafts.length) return;
  DATA.quiz.push(...pendingImportDrafts);
  const n = pendingImportDrafts.length;
  pendingImportDrafts = []; pendingImportErrors = []; importStatusMessage = '';
  persistAppData();
  renderView();
  showToast(`Đã thêm ${n} câu hỏi vào ngân hàng câu hỏi.`);
}
function cancelImportedQuiz(){
  pendingImportDrafts = []; pendingImportErrors = []; importStatusMessage = '';
  renderView();
}

/* =========================================================
   HÀNH ĐỘNG: XEM / XUẤT / XOÁ KẾT QUẢ ĐÃ NỘP
========================================================= */
async function toggleResultsView(){
  resultsViewOpen = !resultsViewOpen;
  if (resultsViewOpen){ QUIZ_RESULTS = await loadQuizResults(); }
  renderView();
}
async function refreshResultsView(){
  QUIZ_RESULTS = await loadQuizResults();
  renderView();
  showToast('Đã làm mới danh sách kết quả.');
}
function exportResultsCSV(){
  const header = ['Họ và tên','Năm sinh','Điểm','Tổng câu','Tỉ lệ (%)','Thời điểm nộp'];
  const lines = [header.join(',')];
  QUIZ_RESULTS.forEach(r=>{
    const row = [r.name, r.birthYear, r.score, r.total, r.percent, r.submittedAt].map(v=>'"'+String(v).replace(/"/g,'""')+'"');
    lines.push(row.join(','));
  });
  const csv = lines.join('\r\n');
  const blob = new Blob(["\uFEFF"+csv], {type:'text/csv;charset=utf-8;'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'ket-qua-on-tap.csv';
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
async function clearResultsHandler(){
  if (!confirm('Xoá toàn bộ kết quả đã nộp? Không thể hoàn tác.')) return;
  await clearQuizResultsStorage();
  renderView();
  showToast('Đã xoá toàn bộ kết quả.');
}

/* =========================================================
   UỶ QUYỀN SỰ KIỆN (event delegation) TRONG #view-root
========================================================= */
function onViewRootClick(e){
  let el;
  if ((el = e.target.closest('[data-goto]'))){ switchView(el.dataset.goto); return; }
  if ((el = e.target.closest('[data-open-scenario]'))){ currentScenarioId = el.dataset.openScenario; scenarioEditOpen=false; renderView(); window.scrollTo({top:0,behavior:'smooth'}); return; }
  if ((el = e.target.closest('[data-back-scenarios]'))){ currentScenarioId = null; scenarioEditOpen=false; renderView(); return; }
  if ((el = e.target.closest('[data-part]'))){ currentPart = el.dataset.part; editingRuleId=null; renderView(); return; }
  if ((el = e.target.closest('[data-fs-group]'))){ currentFsGroup = el.dataset.fsGroup; renderView(); return; }
  if ((el = e.target.closest('[data-mt-group]'))){ currentMtGroup = el.dataset.mtGroup; renderView(); return; }

  if (e.target.closest('[data-toggle-settings-edit]')){ settingsEditOpen = !settingsEditOpen; renderView(); return; }
  if (e.target.closest('[data-save-settings]')){ saveSettingsFromForm(); return; }
  if (e.target.closest('[data-cancel-settings]')){ settingsEditOpen = false; renderView(); return; }
  if (e.target.closest('[data-reset-defaults]')){ resetToDefaults(); return; }
  if (e.target.closest('[data-add-banner-image]')){
    const container = document.getElementById('banner-images-list');
    if (container) container.insertAdjacentHTML('beforeend', bannerImageRowHTML('',''));
    return;
  }
  if ((el = e.target.closest('[data-remove-banner-image]'))){
    const row = el.closest('.signal-row');
    if (row) row.remove();
    return;
  }
  if (e.target.closest('[data-banner-prev]')){
    const imgs = DATA.settings.bannerImages||[];
    if (imgs.length){ bannerCarouselIndex = (bannerCarouselIndex-1+imgs.length)%imgs.length; updateBannerCarouselDisplay(); startBannerCarousel(); }
    return;
  }
  if (e.target.closest('[data-banner-next]')){
    const imgs = DATA.settings.bannerImages||[];
    if (imgs.length){ bannerCarouselIndex = (bannerCarouselIndex+1)%imgs.length; updateBannerCarouselDisplay(); startBannerCarousel(); }
    return;
  }
  if ((el = e.target.closest('[data-banner-dot]'))){
    bannerCarouselIndex = parseInt(el.dataset.bannerDot,10)||0;
    updateBannerCarouselDisplay();
    startBannerCarousel();
    return;
  }

  if ((el = e.target.closest('[data-edit-rule]'))){ editingRuleId = (editingRuleId===el.dataset.editRule) ? null : el.dataset.editRule; renderView(); return; }
  if ((el = e.target.closest('[data-save-rule]'))){ saveRuleFromForm(el.dataset.saveRule); return; }
  if (e.target.closest('[data-cancel-rule]')){ editingRuleId = null; renderView(); return; }

  if (e.target.closest('[data-add-scenario]')){ addNewScenario(); return; }
  if (e.target.closest('[data-edit-scenario]')){ scenarioEditOpen = !scenarioEditOpen; renderView(); return; }
  if ((el = e.target.closest('[data-save-scenario]'))){ saveScenarioFromForm(el.dataset.saveScenario); return; }
  if (e.target.closest('[data-cancel-scenario]')){ scenarioEditOpen = false; renderView(); return; }
  if ((el = e.target.closest('[data-delete-scenario]'))){ deleteScenarioById(el.dataset.deleteScenario); return; }
  if ((el = e.target.closest('[data-add-signal]'))){
    const container = document.getElementById('signals-list-' + el.dataset.addSignal);
    if (container){
      container.insertAdjacentHTML('beforeend', signalRowHTML('', ''));
      const inputs = container.querySelectorAll('.signal-input');
      inputs[inputs.length-1].focus();
    }
    return;
  }
  if ((el = e.target.closest('[data-remove-signal]'))){
    const row = el.closest('.signal-row');
    if (row) row.remove();
    return;
  }
  if ((el = e.target.closest('[data-test-signal-audio]'))){
    const row = el.closest('.signal-row');
    const audioInput = row ? row.querySelector('.signal-audio-input') : null;
    const url = audioInput ? audioInput.value.trim() : '';
    if (!url){ showToast('Chưa nhập URL âm thanh để thử.'); return; }
    playSignalAudio(url, null);
    return;
  }
  if ((el = e.target.closest('[data-play-audio]'))){
    playSignalAudio(el.dataset.playAudio, el);
    return;
  }

  if (e.target.closest('[data-start-quiz]')){ startQuizWithTakerInfo(); return; }
  if ((el = e.target.closest('[data-quiz-opt]'))){
    if (quizSelected===null){
      quizSelected = parseInt(el.dataset.quizOpt,10);
      const q = quizSessionQuestions[quizIndex];
      if (quizSelected===q.correct) quizScore++;
      saveQuizSessionToStorage();
      renderView();
    }
    return;
  }
  if (e.target.closest('[data-quiz-next]')){
    quizIndex++; quizSelected=null;
    if (quizIndex>=quizSessionQuestions.length){
      quizFinished = true;
      clearQuizTimer();
      submitQuizResult();
      clearQuizSessionStorage();
    } else {
      saveQuizSessionToStorage();
    }
    renderView();
    return;
  }
  if (e.target.closest('[data-quiz-restart]')){
    clearQuizTimer();
    quizDeadline = null;
    quizIndex=0; quizScore=0; quizSelected=null; quizFinished=false; quizTaker=null; quizAutoSubmitted=false;
    quizSessionQuestions = null; quizLoadError = '';
    clearQuizSessionStorage();
    renderView();
    return;
  }
  if (e.target.closest('[data-toggle-quiz-manage]')){ quizManageMode = !quizManageMode; editingQuizId=null; renderView(); return; }
  if (e.target.closest('[data-add-quiz]')){ addNewQuiz(); return; }
  if (e.target.closest('[data-toggle-webhook-panel]')){ webhookPanelOpen = !webhookPanelOpen; renderView(); return; }
  if (e.target.closest('[data-save-webhook]')){ saveWebhookUrl(); return; }
  if (e.target.closest('[data-toggle-import-panel]')){ importPanelOpen = !importPanelOpen; renderView(); return; }
  if (e.target.closest('[data-download-template]')){ downloadQuizTemplate(); return; }
  if (e.target.closest('[data-import-file]')){ handleExcelFileImport(); return; }
  if (e.target.closest('[data-import-sheet]')){ handleSheetImport(); return; }
  if (e.target.closest('[data-commit-import]')){ commitImportedQuiz(); return; }
  if (e.target.closest('[data-cancel-import]')){ cancelImportedQuiz(); return; }
  if (e.target.closest('[data-toggle-results-view]')){ toggleResultsView(); return; }
  if (e.target.closest('[data-refresh-results]')){ refreshResultsView(); return; }
  if (e.target.closest('[data-export-results-csv]')){ exportResultsCSV(); return; }
  if (e.target.closest('[data-clear-results]')){ clearResultsHandler(); return; }
  if ((el = e.target.closest('[data-edit-quiz]'))){ editingQuizId = (editingQuizId===el.dataset.editQuiz) ? null : el.dataset.editQuiz; renderView(); return; }
  if ((el = e.target.closest('[data-save-quiz]'))){ saveQuizFromForm(el.dataset.saveQuiz); return; }
  if (e.target.closest('[data-cancel-quiz]')){ editingQuizId = null; renderView(); return; }
  if ((el = e.target.closest('[data-delete-quiz]'))){ deleteQuizById(el.dataset.deleteQuiz); return; }
}

/* =========================================================
   KHỞI TẠO
========================================================= */
function playSignalAudio(url, btnEl){
  const player = document.getElementById('global-audio-player');
  if (!player || !url) return;
  document.querySelectorAll('.sound-badge.playing').forEach(b=>{ if (b!==btnEl) b.classList.remove('playing'); });
  if (player.dataset.currentUrl === url && !player.paused){
    player.pause();
    player.currentTime = 0;
    player.dataset.currentUrl = '';
    if (btnEl) btnEl.classList.remove('playing');
    return;
  }
  player.dataset.currentUrl = url;
  player.src = url;
  if (btnEl) btnEl.classList.add('playing');
  const playPromise = player.play();
  if (playPromise && playPromise.catch){
    playPromise.catch(()=>{
      showToast('Không phát được âm thanh cho tín hiệu này. Kiểm tra lại URL âm thanh.');
      if (btnEl) btnEl.classList.remove('playing');
      player.dataset.currentUrl = '';
    });
  }
}

function wireGlobalEvents(){
  document.getElementById('view-root').addEventListener('click', onViewRootClick);
  document.getElementById('main-nav').addEventListener('click', e=>{
    const toggleBtn = e.target.closest('[data-nav-toggle]');
    if (toggleBtn){
      const dropdown = toggleBtn.closest('.nav-dropdown');
      const wasOpen = dropdown.classList.contains('open');
      document.querySelectorAll('.nav-dropdown.open').forEach(d=>d.classList.remove('open'));
      if (!wasOpen) dropdown.classList.add('open');
      return;
    }
    const btn = e.target.closest('.nav-btn, .nav-dropdown-item'); if (!btn || !btn.dataset.view) return;
    document.querySelectorAll('.nav-dropdown.open').forEach(d=>d.classList.remove('open'));
    switchView(btn.dataset.view);
  });
  document.addEventListener('click', e=>{
    if (!e.target.closest('.nav-dropdown')){
      document.querySelectorAll('.nav-dropdown.open').forEach(d=>d.classList.remove('open'));
    }
  });
  document.getElementById('login-toggle-btn').addEventListener('click', ()=>{ isLoggedIn ? doLogout() : openLoginModal(); });
  document.getElementById('login-modal-close').addEventListener('click', closeLoginModal);
  document.getElementById('login-submit-btn').addEventListener('click', attemptLogin);
  document.getElementById('login-pass').addEventListener('keydown', e=>{ if (e.key==='Enter') attemptLogin(); });
  document.getElementById('login-user').addEventListener('keydown', e=>{ if (e.key==='Enter') attemptLogin(); });
  document.getElementById('login-modal').addEventListener('click', e=>{ if (e.target.id==='login-modal') closeLoginModal(); });
  document.addEventListener('keydown', e=>{ if (e.key==='Escape'){ closeLoginModal(); document.querySelectorAll('.nav-dropdown.open').forEach(d=>d.classList.remove('open')); } });
  const audioPlayer = document.getElementById('global-audio-player');
  audioPlayer.addEventListener('ended', ()=>{
    document.querySelectorAll('.sound-badge.playing').forEach(b=>b.classList.remove('playing'));
    audioPlayer.dataset.currentUrl = '';
  });
  audioPlayer.addEventListener('error', ()=>{
    if (audioPlayer.dataset.currentUrl){
      showToast('Không phát được âm thanh — kiểm tra lại URL âm thanh.');
      document.querySelectorAll('.sound-badge.playing').forEach(b=>b.classList.remove('playing'));
      audioPlayer.dataset.currentUrl = '';
    }
  });
}

async function init(){
  wireGlobalEvents();
  DATA = await loadAppData();
  restoreQuizSessionFromStorage();
  renderBrand();
  updateAuthUI();
  setActiveNav();
  renderView();
  if (!storageAvailable){
    showToast('Lưu ý: Tài liệu sử dụng nội bộ. Miễn trừ trách nhiệm liên quan đến bản quyển và sử dụng phi thương mại | Gmail: dinhthiktts@gmail.com');
  }
}
init();
